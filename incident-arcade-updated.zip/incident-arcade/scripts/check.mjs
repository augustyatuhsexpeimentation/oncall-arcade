import { readdir } from 'node:fs/promises';
import { resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
const root=resolve(import.meta.dirname,'..');
let checked=0;
for(const dir of ['src','scripts','tests']){
  for(const file of await readdir(resolve(root,dir))){
    if(!/\.(m?js)$/.test(file))continue;
    const check=spawnSync(process.execPath,['--check',resolve(root,dir,file)],{encoding:'utf8'});
    if(check.status!==0){console.error(check.stderr);process.exit(1);}
    checked++;
  }
}
console.log(`${checked} JavaScript files passed syntax checks.`);

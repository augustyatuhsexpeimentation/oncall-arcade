import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
const root=resolve(import.meta.dirname,'..');
const args=process.argv.slice(2);
const get=key=>args[args.indexOf(key)+1];
if(!args.includes('--repo')||!args.includes('--site')){
  console.error('Usage: node scripts/configure.mjs --repo https://github.com/OWNER/REPOSITORY --site https://OWNER.github.io/REPOSITORY/');process.exit(1);
}
try{
  const repository=get('--repo');
  if(!/^https:\/\/github\.com\/[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+\/?$/.test(repository))throw new Error('Use a public GitHub repository URL.');
  const site=new URL(get('--site'));
  if(site.protocol!=='https:'||site.username||site.password)throw new Error('Use the public HTTPS URL without credentials.');
  site.hash='';site.search='';if(!site.pathname.endsWith('/'))site.pathname+='/';
  const escape=s=>s.replace(/[&"<>]/g,c=>({'&':'&amp;','"':'&quot;','<':'&lt;','>':'&gt;'}[c]));
  await writeFile(resolve(root,'src/site-config.js'),`/** Public launch configuration. No secrets belong here. */\nexport const SITE = Object.freeze(${JSON.stringify({repository,author:'Incident Arcade contributors'},null,2)});\n`);
  let html=await readFile(resolve(root,'index.html'),'utf8');
  const meta=`<!-- SOCIAL_META_START -->\n  <link rel="canonical" href="${escape(site.href)}">\n  <meta property="og:url" content="${escape(site.href)}">\n  <meta property="og:image" content="${escape(new URL('assets/social-card.png',site).href)}">\n  <meta property="og:image:width" content="1200">\n  <meta property="og:image:height" content="630">\n  <meta property="og:image:alt" content="A comparison card from the Incident Arcade teaching simulation">\n  <!-- SOCIAL_META_END -->`;
  html=html.includes('<!-- SOCIAL_META_START -->')?html.replace(/<!-- SOCIAL_META_START -->[\s\S]*?<!-- SOCIAL_META_END -->/,meta):html.replace('</head>',`  ${meta}\n</head>`);
  await writeFile(resolve(root,'index.html'),html);
  let readme=await readFile(resolve(root,'README.md'),'utf8');
  readme=readme.replace(/<!-- LIVE_LINK_START -->[\s\S]*?<!-- LIVE_LINK_END -->/,`<!-- LIVE_LINK_START -->\n**[Play the live incident](${site.href})** | **[Browse the source](${repository})**\n<!-- LIVE_LINK_END -->`);
  await writeFile(resolve(root,'README.md'),readme);
  console.log('Updated src/site-config.js, index.html, and README.md. Review, commit, and push the changes.');
}catch(error){console.error(error.message);process.exit(1);}

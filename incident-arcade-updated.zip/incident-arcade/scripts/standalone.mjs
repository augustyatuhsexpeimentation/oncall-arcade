/** Build a double-clickable offline preview without installing a bundler. */
import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
const root=resolve(import.meta.dirname,'..');
let html=await readFile(resolve(root,'index.html'),'utf8');
const css=await readFile(resolve(root,'styles.css'),'utf8');
const modules=['scenario','engine','replay','scene','share-card','site-config','episodes','audio','progress','app'];
let code='';
for(const name of modules){
  let source=await readFile(resolve(root,`src/${name}.js`),'utf8');
  source=source.replace(/^import .*?;\s*$/gm,'').replace(/^export /gm,'');
  if(name==='app')source=source.replace("new Worker(new URL('./worker.js', import.meta.url), { type: 'module' })", "(() => { throw new Error('Offline preview uses the local engine'); })()");
  code+=`\n// ---- ${name}.js ----\n${source}\n`;
}
const icon=await readFile(resolve(root,'assets/favicon.svg'),'utf8');
html=html.replace('<link rel="stylesheet" href="./styles.css">',`<style>${css}</style>`);
html=html.replace('<script type="module" src="./src/app.js"></script>','');
html=html.replaceAll('href="./"', 'href="#playground"');
html=html.replace('href="./assets/favicon.svg"',`href="data:image/svg+xml,${encodeURIComponent(icon)}"`);
html=html.replace('</body>',`<script type="module">${code.replaceAll('</script','<\\/script')}</script>\n</body>`);
await writeFile(resolve(root,'preview.html'),html);
console.log('Offline preview ready: preview.html. The normal index.html remains the deployment entrypoint.');

import { cp, mkdir, rm } from 'node:fs/promises';
import { resolve } from 'node:path';
const root = resolve(import.meta.dirname, '..');
const out = resolve(root, 'dist');
await rm(out, { recursive: true, force: true });
await mkdir(out, { recursive: true });
for (const file of ['index.html', 'styles.css', 'src', 'assets', '.nojekyll', '_headers', 'docs/README-SOURCE.md', 'LICENSE']) {
  await cp(resolve(root, file), resolve(out, file), { recursive: true });
}
console.log('Static site ready in dist/. No dependencies, bundler, or secrets required.');

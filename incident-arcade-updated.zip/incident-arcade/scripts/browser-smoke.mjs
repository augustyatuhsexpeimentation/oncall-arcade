/**
 * Optional real-browser integration checks, using Chrome's DevTools protocol.
 * Needs Node 22+ and a locally installed Chrome/Chromium. No npm dependencies.
 * Run: node scripts/browser-smoke.mjs
 * Or: CHROME_BIN=/path/to/chrome node scripts/browser-smoke.mjs
 * This script uses an ephemeral profile and binds debugging to localhost.
 */
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {access,mkdtemp,mkdir,writeFile,rm,readFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {resolve,join} from 'node:path';
import net from 'node:net';
import {newRun,SCENARIO,getScenario} from '../src/scenario.js';
import {changePolicy} from '../src/engine.js';
import {encodeRun} from '../src/replay.js';
const root=resolve(import.meta.dirname,'..');
const candidates=[process.env.CHROME_BIN,'/usr/bin/google-chrome','/usr/bin/google-chrome-stable','/usr/bin/chromium','/usr/bin/chromium-browser','/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'].filter(Boolean);
let chrome;
for(const file of candidates){try{await access(file);chrome=file;break;}catch{}}
if(!chrome){console.error('Chrome/Chromium was not found. Set CHROME_BIN to its executable path. No browser tests were run.');process.exit(2);}
const freePort=()=>new Promise((resolve,reject)=>{const s=net.createServer();s.on('error',reject);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(()=>resolve(p));});});
const port=await freePort(),debugPort=await freePort();
const profile=await mkdtemp(join(tmpdir(),'incident-arcade-browser-'));
const artifacts=resolve(root,'test-results');await mkdir(artifacts,{recursive:true});
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const server=spawn(process.execPath,['scripts/serve.mjs'],{cwd:root,env:{...process.env,PORT:String(port)},stdio:'pipe'});
const browser=spawn(chrome,['--headless=new','--disable-dev-shm-usage','--no-sandbox','--no-first-run','--no-default-browser-check',`--remote-debugging-port=${debugPort}`,'--remote-debugging-address=127.0.0.1',`--user-data-dir=${profile}`,'about:blank'],{stdio:'pipe'});
let ws;const pageErrors=[],networkFailures=[],requests=[];let browserLog='';
browser.stderr.on('data',chunk=>{browserLog+=chunk.toString();});
browser.on('error',error=>{browserLog+=error.message;});
server.on('error',error=>{browserLog+=error.message;});
const pending=new Map();let nextId=0;
function command(method,params={}){
  return new Promise((resolve,reject)=>{const id=++nextId;const timeout=setTimeout(()=>{pending.delete(id);reject(new Error(`CDP timeout: ${method}`));},12000);pending.set(id,{resolve,reject,timeout});ws.send(JSON.stringify({id,method,params}));});
}
async function evaluate(expression,userGesture=false){const r=await command('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true,userGesture});if(r.exceptionDetails)throw new Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;}
async function waitFor(expression){await evaluate(`new Promise((resolve,reject)=>{const start=Date.now();const t=setInterval(()=>{try{if(${expression}){clearInterval(t);resolve(true)}else if(Date.now()-start>8000){clearInterval(t);reject(Error('Condition timeout'))}}catch(e){clearInterval(t);reject(e)}},30)})`);}
async function click(selector){await evaluate(`document.querySelector(${JSON.stringify(selector)}).click()`,true);}
async function shot(name){const metrics=await command('Page.getLayoutMetrics');const size=metrics.cssContentSize;const r=await command('Page.captureScreenshot',{format:'png',captureBeyondViewport:true,clip:{x:0,y:0,width:Math.ceil(size.width),height:Math.min(16000,Math.ceil(size.height)),scale:1}});await writeFile(resolve(artifacts,name),Buffer.from(r.data,'base64'));}
try{
  let target;
  for(let i=0;i<100;i++){
    try{await fetch(`http://127.0.0.1:${port}`);target=await(await fetch(`http://127.0.0.1:${debugPort}/json/new?about:blank`,{method:'PUT'})).json();if(target.webSocketDebuggerUrl)break;}catch{}
    await sleep(100);
  }
  if(!target?.webSocketDebuggerUrl)throw new Error(`Could not start Chrome. ${browserLog.slice(-1500)}`);
  ws=new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
  ws.addEventListener('message',event=>{
    const message=JSON.parse(event.data);
    if(message.id){const task=pending.get(message.id);if(!task)return;clearTimeout(task.timeout);pending.delete(message.id);message.error?task.reject(new Error(message.error.message)):task.resolve(message.result);}
    if(message.method==='Runtime.exceptionThrown')pageErrors.push(message.params.exceptionDetails.exception?.description||message.params.exceptionDetails.text);
    if(message.method==='Network.responseReceived'&&message.params.response.status>=400)networkFailures.push(message.params.response.url);
    if(message.method==='Network.requestWillBeSent')requests.push(message.params.request.url);
  });
  await command('Page.enable');await command('Runtime.enable');await command('Network.enable');
  await command('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});
  const base=`http://127.0.0.1:${port}/`;
  await command('Page.navigate',{url:base});
  await waitFor(`document.getElementById('play-button') && !document.getElementById('play-button').disabled`);
  assert.equal(await evaluate(`document.body.dataset.stage`),'intro');
  assert.equal(await evaluate(`document.getElementById('audio-summary').textContent`),'Audio off');
  await shot('01-desktop-start.png');
  await click('#take-pager');await click('#tab-traffic');
  assert.equal(await evaluate(`document.getElementById('clue-count').textContent`),'1 / 3');
  await click('.scene-character[data-evidence="database"]');
  assert.equal(await evaluate(`document.getElementById('clue-count').textContent`),'2 / 3');
  await click('#guide-next');await shot('02-choose-a-fix.png');
  await click('[data-preset="budget"]');
  await waitFor(`document.body.dataset.stage==='watch'&&!document.getElementById('finish-button').disabled`);
  await click('#finish-button');assert.match(await evaluate(`document.getElementById('result-numbers').textContent`),/1,709/);
  await shot('03-desktop-result.png');
  await click('#retry-button');await waitFor(`!document.querySelector('[data-preset="harder"]').disabled`);
  await click('[data-preset="harder"]');await waitFor(`!document.getElementById('finish-button').disabled`);await click('#finish-button');
  await click('#result-compare');
  assert.deepEqual(await evaluate(`Array.from(document.querySelectorAll('.big-number')).map(n=>n.textContent)`),['1,709','503']);
  await shot('04-comparison.png');await click('#modal-close');
  await click('#next-case-button');await waitFor(`document.getElementById('incident-title').textContent==='Everybody wants a tote'&&!document.getElementById('guide-next').disabled`);
  await click('#guide-next');await click('[data-preset="scale"]');await waitFor(`!document.getElementById('finish-button').disabled`);await click('#finish-button');
  assert.match(await evaluate(`document.getElementById('result-numbers').textContent`),/10,699/);
  await click('#next-case-button');await waitFor(`document.getElementById('incident-title').textContent==='It worked on my laptop'&&!document.getElementById('guide-next').disabled`);
  await click('#tab-changes');await click('#guide-next');await click('[data-preset="rollback"]');await waitFor(`!document.getElementById('finish-button').disabled`);await click('#finish-button');
  assert.match(await evaluate(`document.getElementById('result-numbers').textContent`),/4,302/);
  await click('#lesson-details>summary');await click('[data-answer="2"]');
  assert.match(await evaluate(`document.getElementById('reflection-feedback').textContent`),/Exactly/);
  assert.equal(await evaluate(`document.getElementById('casebook-count').textContent`),'3 / 3 explored');
  // Enabling audio is an explicit gesture, never a page-load side effect.
  await click('#audio-summary');await click('#sound-toggle');
  await waitFor(`document.getElementById('audio-summary').textContent==='Audio on'`);
  await click('#music-toggle');await sleep(300);await click('#music-toggle');await click('#sound-toggle');
  assert.equal(await evaluate(`document.getElementById('audio-summary').textContent`),'Audio off');
  await click('#audio-summary');
  const shared=changePolicy(newRun(42,'flash-sale'),18,{...getScenario('flash-sale').initial,admission:50});
  await command('Page.navigate',{url:`${base}#run=${encodeRun(shared)}`});
  await waitFor(`document.getElementById('incident-title')?.textContent==='Everybody wants a tote'&&!document.getElementById('retry-button').disabled`);
  assert.match(await evaluate(`document.getElementById('result-numbers').textContent`),/5,056/);
  await command('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});
  await click('#retry-button');await waitFor(`document.body.dataset.stage==='choose'&&!document.querySelector('[data-preset="scale"]').disabled`);
  assert.equal(await evaluate(`location.hash`),'');
  await shot('05-mobile-choices.png');
  assert.ok(await evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'),'Mobile page has horizontal overflow');
  await click('[data-preset="scale"]');await waitFor(`!document.getElementById('finish-button').disabled`);await click('#finish-button');
  await shot('06-mobile-result.png');
  assert.ok(await evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'),'Mobile result has horizontal overflow');
  await command('Emulation.setDeviceMetricsOverride',{width:320,height:740,deviceScaleFactor:1,mobile:true});
  await shot('07-small-mobile.png');
  assert.ok(await evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'),'Small mobile page has horizontal overflow');
  await click('#motion-button');assert.equal(await evaluate(`document.body.classList.contains('reduced-motion')`),true);
  await click('#privacy-button');assert.equal(await evaluate(`document.getElementById('modal').open`),true);
  await command('Input.dispatchKeyEvent',{type:'keyDown',key:'Escape',code:'Escape',windowsVirtualKeyCode:27});
  await command('Input.dispatchKeyEvent',{type:'keyUp',key:'Escape',code:'Escape',windowsVirtualKeyCode:27});
  assert.equal(await evaluate(`document.getElementById('modal').open`),false);
  assert.deepEqual(pageErrors,[],'Uncaught browser errors');assert.deepEqual(networkFailures,[],'Failed asset requests');
  assert.equal(requests.filter(url=>/^https?:/.test(url)&&!url.startsWith(base)).length,0,'Unexpected external runtime requests');
  console.log('PASS: guided flow, three incidents, automatic branch comparison, reflection, opt-in audio controls, shared replay, mobile overflow, reduced motion, dialogs, and network checks.');
  await writeFile(resolve(artifacts,'browser-report.json'),JSON.stringify({status:'passed',pageErrors,networkFailures,requests:requests.length},null,2));
}catch(error){
  console.error(error);await writeFile(resolve(artifacts,'browser-report.json'),JSON.stringify({status:'failed',message:error.message,pageErrors,networkFailures,browserLog:browserLog.slice(-3000)},null,2));
  if(ws?.readyState===1)try{await shot('failure.png');}catch{}
  process.exitCode=1;
}finally{
  for(const task of pending.values())clearTimeout(task.timeout);
  ws?.close();browser.kill();server.kill();await sleep(300);await rm(profile,{recursive:true,force:true}).catch(()=>{});
}

# Contributing

A useful contribution makes the incident easier to reason about, not just larger.

## Start locally

Run `node scripts/serve.mjs`, `node --test tests/*.test.mjs`, and `node scripts/check.mjs`. Node 22+ is sufficient; package installation is not required.

## Model changes

Read docs/MODEL.md first. Keep simulation logic out of the DOM. Preserve independent arrival randomness, unique-customer accounting, bounded workloads, and reproducible replays. Add a failing test for a bug before fixing it. Describe why changed fixtures are correct; bump the engine version when semantics change.

## Interface changes

Preserve keyboard access, visible focus, reduced motion, useful labels, and responsive behavior. Avoid external services and remote fonts. Use the browser smoke script, inspect screenshots, and test a phone-sized layout. Original SVG artwork is welcome; do not copy third-party assets without a compatible license and attribution.

## Scenario proposals

Use the scenario proposal issue template. Explain the failure mechanism, what users can observe, what they can change, a useful learning outcome, and the model's limitations. A published-incident adaptation must distinguish documented facts from hypothetical alternatives.

## Pull requests

Keep changes focused. Explain the behavior before and after, name the checks you ran, and disclose untested environments. Do not claim all browsers are supported from a Node test result alone.

By submitting a contribution, you agree that your contribution is available under the project's MIT license.

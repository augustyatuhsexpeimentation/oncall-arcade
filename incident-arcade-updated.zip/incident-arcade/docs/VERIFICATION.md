# Verification record

Package and engine: Incident Arcade 2.0.0
Date: October 29, 2026
Scenarios: retry-storm, flash-sale, bad-rollout; scenario version 1 each
Executed-check environment: Node.js 22.16.0 on Linux

## Checks actually executed

| Check | Result |
| --- | --- |
| `node --test tests/*.test.mjs` | 110 passed; 0 failed; 0 skipped |
| `node scripts/check.mjs` | 25 top-level JavaScript source/script/test files parse |
| `node --check tests/support/dom.mjs` | The additional test-support module parses |
| Model accounting and determinism | Passed for all three workloads, their supported choices, and multiple seeds |
| Scenario-specific mechanisms | Retry limits reduce amplification; extra capacity helps the surge; reversible rollback restores capacity |
| Replay validation and compatibility | Bounded input, rejected invalid versions/policies, reproducible replay, supported v1 retry-storm normalization |
| Local progress | Bounded/sanitized state, attempt recording, and explanatory results |
| Guided UI state changes | Passed in a custom nonvisual DOM harness across the three cases, retry/compare, reflection, free play, replay restore, and privacy controls |
| Audio state management | Passed against mock Web Audio objects: silent startup, explicit enablement, separate switches, bounded volume/voices, hidden-page suspension, and rapid-toggle races |
| Local HTTP server | MIME types, method behavior, missing paths, and traversal boundary tested |
| Static package | Includes engine, worker, artwork, license, and source fallback |
| Offline preview | Complete bundled script generated and syntax-checked |
| Configuration helper | Public URLs inserted correctly and repeat execution stays idempotent |
| CSS | Parsed with tinycss2 with zero parser errors |

Tests use actual model output for fixture counts, not hand-authored score changes. The existing social-card PNG is retained from the original version and reflects a reproducible retry-storm experiment; it is not a screenshot of the updated interface.

## Important: what these checks do not prove

The DOM harness is deliberately lightweight. It does not render CSS, measure real layouts, implement a real accessibility tree, play audio, exercise actual permissions, or substitute for a browser. Mock AudioContext checks do not establish audio quality or browser autoplay behavior.

`node scripts/browser-smoke.mjs` was attempted and returned:

```text
Chrome/Chromium was not found. Set CHROME_BIN to its executable path. No browser tests were run.
```

Exit code: 2. No real-browser tests, rendered screenshot review, or audio listening were completed in this environment. Mobile devices, Safari/Firefox, clipboard/download prompts, real PNG export rendering, and assistive-technology behavior remain to be checked.

The project has not been deployed into the owner's account. No live URL, user-study result, engagement figure, retention improvement, or GitHub traction is claimed.

## Included browser check

With Node.js 22+ and Chrome/Chromium installed:

```sh
node scripts/browser-smoke.mjs
```

Or specify an executable:

```sh
CHROME_BIN=/path/to/chrome node scripts/browser-smoke.mjs
```

The script is written to exercise the three guided cases, rewind comparison, reflection, opt-in audio controls, replay links, mobile overflow, reduced motion, dialogs, and unexpected network requests. It also captures desktop and mobile screenshots in `test-results/`.

The included GitHub workflow is configured to run these checks and retain screenshots on an Ubuntu runner. The workflow has been authored, not executed in the owner's future repository. Its outputs still need inspection; a script alone is not evidence of a passing run.

## Before a public launch

1. Open the offline preview and a served/deployed copy in a real browser.
2. Play all three cases and compare two different choices in each.
3. Inspect a narrow phone layout for clipped text, overlapping controls, and awkward scrolling.
4. Enable music/effects separately, adjust volume, mute, switch tabs, and listen for clicks or excessive loudness.
5. Use keyboard-only navigation, the reduced-motion option, and a screen reader.
6. Test replay links in a fresh tab, JSON import/export, and the downloaded PNG image.
7. Ask a new player to explain the goal and the failure mechanism without coaching.

Record the browser, device, findings, and fixes. Do not mark these items complete simply because the automated suite passes.

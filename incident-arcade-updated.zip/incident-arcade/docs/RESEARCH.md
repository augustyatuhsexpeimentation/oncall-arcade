# Research and product decisions

Research checked October 29, 2026. This is a design rationale, not evidence that the finished product is engaging or educationally effective. No user study, retention analysis, or market-size estimate was conducted for this update.

## 1. Let players act before teaching the full control panel

Nicky Case's "Explorable Explanations" describes hooks that need little prior knowledge, building from small mechanics, and an author-guided/player-driven experience. It also emphasizes playtesting rather than assuming an interactive explanation works.

**Decision:** one paused scene, one short goal, three useful clues, three decisions, then measured consequences and an explanation. Keep a separate free-play mode. Do not gate all later cases behind a quiz.

https://blog.ncase.me/explorable-explanations/
https://ncase.me/
https://ncase.me/loopy/

## 2. Borrow simplicity, not somebody else's artwork

Neal.fun's Draw a Perfect Circle leads with one question and a direct action. This is an observed design pattern, not proof that the same layout causes retention in this different product.

**Decision:** an immediately understandable challenge and one main action at each stage. Preserve Incident Arcade's existing original paper/ink scene. No code, assets, branding, or page layouts were copied from either reference creator.

https://neal.fun/perfect-circle/
https://neal.fun/

## 3. Reveal complexity only when it becomes useful

Nielsen Norman Group's progressive-disclosure guidance recommends a small primary set of options and access to advanced features on request, with clearly labeled transitions.

**Decision:** move detailed metrics, manual policies, timeline management, journals, and export tools out of the beginner's first task. Keep choices readable and advanced free play available. This is a justified design hypothesis; usability testing is still necessary.

https://www.nngroup.com/articles/progressive-disclosure/

## 4. Teach three different causal mechanisms

AWS explains how retries can amplify overload and why timing, jitter, and retry limits matter. Google SRE discusses overload, capacity, cascading failures, and evaluating releases. AWS's rollback-safety article warns that some changes are not safely reversible.

**Decision:** add a traffic surge and a reversible-release regression to the original retry-feedback incident. The source material informs the mechanisms, not the invented rates. Count rejected customers as failures. Never state that scaling, disabling retries, or rolling back is universally correct.

https://aws.amazon.com/builders-library/timeouts-retries-and-backoff-with-jitter/
https://sre.google/sre-book/handling-overload/
https://sre.google/sre-book/addressing-cascading-failures/
https://sre.google/workbook/canarying-releases/
https://aws.amazon.com/builders-library/ensuring-rollback-safety-during-deployments/

## 5. Rewind is a learning device, not a punishment system

Case's discussion of exploration and Google SRE's postmortem culture support investigating causes and learning from incidents. Neither source establishes that this particular implementation improves learning.

**Decision:** automatically save the previous attempt when trying another choice. Compare identical incoming customers and equal-length runs. Explain the causal mechanism without grading engineering competence. Include optional reflection rather than a pass/fail credential.

https://blog.ncase.me/explorable-explanations/
https://sre.google/workbook/postmortem-culture/

## 6. Audio must not be a barrier

MDN documents starting Web Audio from user gestures and offering playback/volume control. W3C warns about interfering background audio. Page Visibility provides a mechanism for responding when a page is hidden.

**Decision:** silent startup, independent music/effects toggles, volume, no audio-only clues, tab-hidden suspension. The tune is original and synthesized locally, with source under MIT; no licensing dependency on an external recording.

https://developer.mozilla.org/en-US/docs/Web/API/Web_Audio_API/Best_practices
https://www.w3.org/WAI/WCAG22/Understanding/audio-control.html
https://developer.mozilla.org/en-US/docs/Web/API/Page_Visibility_API

## 7. Respect motion and small screens

W3C guidance covers disabling interaction-triggered animation and larger pointer targets. Meeting some design recommendations does not establish WCAG conformance.

**Decision:** retain reduced-motion controls, keep visual and text explanations, use readable single-column choices on phones, and preserve keyboard operation. Actual browser, assistive-technology, and device checks remain necessary.

https://www.w3.org/WAI/WCAG22/Understanding/animation-from-interactions.html
https://www.w3.org/WAI/WCAG22/Understanding/target-size-enhanced.html

## What the research does NOT establish

It does not establish likely GitHub stars, LinkedIn reach, measured session duration, learning gains, or long-term return use. The proposed first session is roughly 10-20 minutes including experimentation; it is a design target, not a measured result. Three authored incidents are finite content, not an endless game.

The next evidence should come from observing new players: can they explain the goal, make a decision without coaching, voluntarily try another approach, and describe the cause afterward? Add more cases only after fixing confusion in these three.

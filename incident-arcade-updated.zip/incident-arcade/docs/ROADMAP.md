# What comes next

## Shipped in v2

Three authored incidents with different mechanisms; guided first play; automatic retry-and-compare; optional explanations/reflection; local progress; free play; original optional music/effects; replay links, JSON files, and PNG result cards.

## Validate before adding more

The next priority is real-browser and phone QA, listening checks, keyboard/screen-reader testing, and observing first-time players. Fix confusing controls and misleading explanations before adding scenarios. The included automated checks do not prove retention or learning.

## Useful future contributions

Better explanations and translations, reviewed scenario proposals, more robust replay/engine tests, and accessibility fixes. An additional incident must have a distinct cause, observable evidence, meaningful interventions, deterministic tests, and an honest explanation of assumptions.

## Not planned for the simple version

Accounts, paid AI generation, actual cloud provisioning, competitive credentials, streak pressure, and a global leaderboard. Keep the live game free to operate and straightforward to use.

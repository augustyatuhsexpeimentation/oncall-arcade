# Audio: original, optional, local

The background music is an original procedural miniature written for Incident Arcade, not an embedded third-party song. The notes, arrangement, synthesis code, and effects are in `src/audio.js` and included under the repository's MIT license.

No sampled recordings, external audio files, music services, copyrighted-song excerpts, or paid sound libraries are included. There is no attribution requirement to a separate music provider. Retain the repository's MIT notice when redistributing its code/assets.

## Composition

The background loop runs at 84 beats per minute. Four quiet arpeggiated chords span eight 4/4 bars, approximately 22.9 seconds per cycle. A low sine bass enters every two beats. Soft amplitude envelopes avoid hard signal edges. Effects distinguish clues, decisions, rewind, results, and reflections without announcing a universally correct production decision.

## User control

- Both music and effects start off, including after reloading.
- An explicit user gesture creates/resumes Web Audio.
- Music and effects have independent switches and a shared volume control.
- Only the volume preference is remembered; playback permission is not inferred from a previous visit.
- Switching tabs stops the music scheduler and suspends audio; it may resume on return only when previously enabled.
- Audio is not required to play or understand a result.
- Unsupported Web Audio leaves a playable silent game.

Music is intentionally decorative, not evidence about the simulated system. No siren, forced autoplay, audio-only clue, or microphone permission is used.

## Verification boundary

Automated mocks verify state changes, consent, volume limits, voice bounds, and visibility behavior. They cannot establish how the composition sounds. Listening checks on real speakers/headphones, browser audio permissions, and mobile interruption behavior remain outstanding.

References:
https://developer.mozilla.org/en-US/docs/Web/API/Web_Audio_API/Best_practices
https://www.w3.org/WAI/WCAG22/Understanding/audio-control.html
https://developer.mozilla.org/en-US/docs/Web/API/Page_Visibility_API

# Publish the updated game

You need only the extracted project folder. Claude Code and Codex are not required.

## First, try it

1. Extract the ZIP and open `preview.html`.
2. Play each case, enable audio briefly, and try rewind and comparison.
3. Check `docs/VERIFICATION.md` for the browser checks still outstanding.

## Put it online with GitHub Pages

1. Create a public GitHub repository named `incident-arcade`, without initializing another README or license.
2. Upload or push this folder's contents, keeping `index.html`, `styles.css`, `src/`, and `assets/` at the repository root.
3. Include the supplied `.nojekyll` and `.github/` files; do not upload only the ZIP or add an extra enclosing folder.
4. Open **Settings > Pages > Deploy from a branch > main > /(root) > Save**.
5. Open the website address GitHub displays and check the game on a computer and phone.
6. Check the **Actions** test result and its screenshot artifact before a public launch.
7. Add the live address to the repository's **About > Website** field.

Use GitHub's supplied address; buying a domain is unnecessary. Public-repository Pages is available with GitHub Free under its current terms. This project requires no API keys, database, or build service.

### Copy-paste Git commands

Run these inside the extracted `incident-arcade` folder, replacing `YOUR_USERNAME`:

```sh
git init
git add .
git commit -m "Launch Incident Arcade with three playable incidents"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/incident-arcade.git
git push -u origin main
```

Use your normal GitHub sign-in. Never put access tokens in the project.

### Optional: connect the source button and social preview

The game works without this. To link its **Open source** button to your repository and set the public social-image URL, run this with Node.js 22+:

```sh
node scripts/configure.mjs --repo https://github.com/YOUR_USERNAME/incident-arcade --site https://YOUR_USERNAME.github.io/incident-arcade/
node scripts/standalone.mjs
git add .
git commit -m "Configure repository and live website links"
git push
```

Use your actual repository and site URLs. Do not copy the placeholder username into the command unchanged.

## Update a site you already published

1. Replace the old project files with the updated files, preserving your real repository URL in `src/site-config.js`.
2. Run the configuration command again when you have previously configured social metadata.
3. Commit and push the updated files; Pages will publish the changed branch.
4. Reload the website and test all three cases; v2 uses a separate local progress store.

Retry-storm v1 replay files are accepted and normalized to the new engine format; v1 local browser saves are not migrated. No user account or cloud data is involved.

## Small troubleshooting table

| Problem | Fix |
| --- | --- |
| `index.html` is blank when double-clicked | Open `preview.html`, or run `node scripts/serve.mjs`. |
| Pages displays the README | Put `index.html` at the selected publishing root. |
| The source button is not your repository | Run the optional configuration command above. |
| A replay points at your own computer | Copy it from the deployed website, not localhost. |
| The tune is silent | Enable Music in the Audio menu, check volume and device mute, then click again if the browser blocked playback. |
| Chrome is not found for the test script | Set `CHROME_BIN` to your installed Chrome/Chromium executable. |
| An offline replay link is not shareable | Deploy the website first, or use JSON export/import in free play. |

Official source, checked October 29, 2026:
https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
https://docs.github.com/en/pages/quickstart

Free-hosting terms and interface labels can change; no paid upgrade is required by this implementation.

# The model, not the metaphor

## Versioned contract

The engine is version `2.0.0`. The `retry-storm`, `flash-sale`, and `bad-rollout` scenarios each have scenario version `1`. A replay contains these identifiers, a 32-bit seed, and an ordered list of full policy snapshots. Unknown versions are rejected. The one supported legacy format is a v1 retry-storm replay, normalized to v2 with unchanged outcomes. v1 local UI saves are not migrated.

The simulation is pure JavaScript: no clocks, network calls, DOM, `Math.random()`, or external dependencies. Playback time and machine speed cannot change results.

## Shared assumptions and the original retry-storm workload

| Parameter | Value |
| --- | --- |
| Model duration | 90 seconds |
| Internal time step | 100 milliseconds |
| Arrival rate | Approximately 48 new customer operations/second |
| Healthy database capacity | 120 attempts/second |
| Degraded database capacity | 12 attempts/second |
| Background impairment | Starts at +10s; ends at +24s |
| Queue discipline | FIFO |
| Queue limit | 1,200 attempts |
| Customer deadline | 8 seconds from arrival |
| Initial retry budget | 3 retries, plus the original attempt |
| Initial retry timing | One tick after a failure/timeout |
| Initial per-attempt timeout | 1,200 milliseconds |
| Initial admission | 100% |

These numbers were selected to expose the mechanism clearly. They are not calibrated against a real service.

### Three causes, not just three stories

All cases use the same FIFO queue machinery, deadlines, and accounting. The causal inputs differ:

| Case | What changes at +10s | What can remove that pressure |
| --- | --- | --- |
| Retry storm | Capacity falls from 120 to 12 attempts/s until +24s; initial retries are 3. | Limit repeated work so the queue can drain after the temporary impairment ends. |
| Flash crowd | New arrivals rise from about 48 to 180 customers/s until +70s; initial retries are 0. | Add a second modeled worker, or shed some load with explicit lost customers. |
| Bad release | Effective capacity falls from 120 to 24 attempts/s; initial retries are 1 with jitter and a 3s timeout. | A safe code-only rollback restores the previous capacity. |

A flash-crowd worker setting of 2 doubles effective capacity immediately. The release rollback restores capacity immediately but does NOT cancel the queue or retroactively rescue failed operations. These are deliberate teaching assumptions. There is no provisioning delay, monetary simulation, distributed database behavior, irreversible migration, or real cloud access. The bad release remains active throughout the incident unless rolled back.

The guided flow starts with the incident paused at +18s. Every case runs to +90s and has three authored first choices; free play exposes other supported policies.


## Within each 100ms tick

1. Apply the policy change scheduled at the tick boundary.
2. Generate new customers using a counter-based seeded random stream.
3. Admit or reject each customer using a separate stable per-customer draw.
4. Send previously scheduled retries whose customer is still pending.
5. Complete as many queued attempts as the database's available service slots allow.
6. Time out overdue callers and schedule eligible retries.
7. Expire any customer that reaches its overall deadline.
8. Record a frame every 10 ticks, after processing the full second.

Completions are processed before same-tick timeout checks. Time is quantized, so an attempt completed on its timeout tick can succeed. There is no attempt to claim sub-tick latency precision. Unused service slots are lost; they cannot be banked for future traffic.

## Customer operations versus attempts

A customer operation can succeed at most once. It can generate multiple backend attempts. The backend does not cancel attempts when a client stops waiting, the operation fails, or another attempt succeeds. Such attempts remain queued and consume service slots when processed. They are counted as late/redundant work.

A queued attempt completing after its timeout cannot rescue its customer. Nor can a completion after the customer's overall deadline. The model has no write side effects and does not simulate duplicate charges, inventory changes, or idempotency keys.

### Accounting identities

At every reported frame:

```text
incoming customers = successful + failed + pending
backend attempts = processed attempts + queued attempts + overflow rejections
```

Admission rejections are included in failed customers. They do not disappear from the denominator. Queue-overflow rejection counts as an attempted backend call; it can lead to a retry while the customer remains within its budget and deadline.

## Retry policies

The retry limit is the number of additional tries after the original. Allowed values are 0, 1, 3, and 6.

Immediate retry means the next 100ms tick. Jittered retry uses full jitter in the interval from zero to `min(3000ms, 400ms * 2^(retry_number-1))`, quantized up to at least one tick. The random draw is keyed by seed, customer ID, and retry number. Different interventions cannot perturb the future arrival stream.

Per-attempt timeout choices are 600ms, 1,200ms, 3,000ms, and 5,000ms. A new policy changes new attempts and subsequent retry decisions. Existing attempts retain their timeout. A retry already scheduled under an older policy is not cancelled by lowering the budget later. It is still suppressed when the customer has finished or reached its deadline.

Admission choices are 100%, 75%, and 50%. They apply to new customer arrivals only, not to already admitted operations or retries.

## Metrics

**Successful outcomes:** success / (success + failed) among operations resolved during the last five simulated seconds. Pending operations are not included; this is explicitly labelled in the interface.

**Queue:** queued backend attempts, including work whose callers timed out.

**Attempts per checkout:** cumulative backend attempts / cumulative incoming customers. Includes rejected customers in the denominator and queue-overflow attempts in the numerator.

**Incoming customer traffic:** average new arrivals per second across the most recent five seconds (or elapsed time if less than five seconds).

**Comparison cards:** counts over the full 90-second horizon. They show pending customers separately. The reference and current run always use the same arrival seed.

**Stable recovery:** five consecutive one-second observations with recent resolved success at least 95% and queue size below 60. For the retry storm this window cannot begin before +24s, when maintenance ends. For the other cases it cannot begin before +10s, when the incident starts. A recovery timestamp is the end of that qualifying window. This is an illustrative threshold, not a universal definition of recovery or a production SLO.

**Retry animation:** the return path reflects retries sent in the recent five seconds, not the cumulative retry total. Disabling retries does not pretend already scheduled work was cancelled.

No real latency percentiles, monetary costs, user competency scores, or invented infrastructure measurements are displayed.

## Why the outage can outlive the trigger

After capacity returns to 120 attempts/s, 48 new customers/s with three retries could generate approximately 192 attempts/s when calls repeatedly time out. Retries keep the demand above capacity and old work remains in the queue.

A one-retry budget lowers that potential sustained demand to approximately 96 attempts/s, allowing eventual drainage. Turning off retries can drain the queue faster in this deliberately simplified model. This does not imply that retries are generally harmful or that disabling them is generally correct. In real systems, retries can help transient failures, and cancellation, idempotency, backpressure, deadlines, and workload shape change the tradeoff.

Backoff alone is not guaranteed to solve a sustained demand/capacity imbalance. A longer timeout also does not create capacity. The debrief presents these distinctions explicitly.

## Rewind and comparison semantics

Scrubbing changes only the playhead. A new intervention at time T removes existing decisions at T and later in the current branch, then appends the new full policy snapshot. The pinned reference is a separate validated copy.

Pinning captures the current full decision schedule, including its projected 90-second outcome. Comparison is explicitly a full-horizon calculation, even when the playhead is earlier. Replay links share the current decision schedule only, not the pinned reference or notebook state.

## Reproducible examples

Seed 42; one action at +18s; full 90-second horizon:

| Case | No-change successes | Intervention | Intervention successes | Stable recovery |
| --- | ---: | --- | ---: | --- |
| Retry storm | 503 | Limit retries to 1 | 1,709 | +76s |
| Flash crowd | 1,202 | Set workers to 2 | 10,699 | +31s |
| Bad release | 632 | Roll back the release | 4,302 | +26s |

The retry-storm and bad-release workloads each contain 4,302 incoming customers. The flash crowd contains 12,229. Results are not comparable across different incidents as a player ranking. Some runs end with pending customers, which remain reported separately. The improvement in the guided results always uses the no-change baseline; detailed comparison can use the player's previous attempt.

## Boundaries

No network latency, independent API bottleneck, CPU scheduling, cache, real auto-scaling, write side effects, distributed consistency, connection pools, multilevel retry hierarchy, or migration safety is modeled. The second worker is a capacity multiplier, not an independent distributed node. This is one bounded queue and one retrying caller per customer.

Sources informing the qualitative mechanisms:
https://aws.amazon.com/builders-library/timeouts-retries-and-backoff-with-jitter/
https://sre.google/sre-book/handling-overload/
https://sre.google/workbook/canarying-releases/
https://aws.amazon.com/builders-library/ensuring-rollback-safety-during-deployments/

The assumptions and numerical results are original illustrative choices, not measurements from these sources.


# Incident Arcade source

Incident Arcade v2 is an MIT-licensed illustrated learning game with three short incidents. Its complete source includes the website, deterministic engine, original SVG artwork, original procedural music/effects, replay tools, and automated tests. No backend or paid API is required.

This deployment has not configured its repository link yet. Ask the person who shared the app for its GitHub address. This page is a configuration fallback, not a fabricated repository URL.

Maintainers: set the repository in src/site-config.js, or run scripts/configure.mjs with --repo and --site. The Open source button will then link to your project.

The game is inspired by learning-through-play experiences at ncase.me and neal.fun. It is not affiliated with those creators and uses none of their artwork or code. Its simulations are fictional teaching models, not production operating instructions.

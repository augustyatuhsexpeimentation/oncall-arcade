# A small, truthful launch

## Show the interaction

Record a short sequence: inspect a clue, make a plausible mistake, watch its consequences, rewind, and compare a different decision. Show the real app and its actual model output, not a staged graph. Mention that the model is simplified.

## Example post

I made a small game about a broken online shop.

You investigate a clue, try a fix, and see what happens. Then you can rewind and compare another decision against the same customers.

There are three short incidents: a retry storm, a flash crowd, and a bad release. The illustration, optional music, and simulation all run locally in your browser.

Free, open source, no account or AI key. It is a teaching model, not a production runbook.

What would you change first?

Live: [your actual deployed address]
Source: [your actual repository]

## Before posting

1. Finish real-browser checks, listen to the audio, and inspect the mobile layout.
2. Test a public replay link in a fresh tab.
3. Ask a few new users to play without coaching and fix any obvious confusion.
4. Include both the live app and source; invite useful feedback, not manufactured votes.

Do not claim verified retention, hours of gameplay, complete accessibility, or production fidelity. None of those has been established.

# Security boundaries

The app has no server-side database, credentials, login, payment flow, model API, or user-content publication endpoint. Replay imports are fixed-schema data and cannot execute code. The model and action history are bounded to prevent unbounded simulations.

A static host may keep its own request logs. Browser local storage is not encrypted secret storage. Do not place secrets or customer incident data in this repository or in a replay. Shared links are readable by their recipients, and client-side results are not tamper-proof.

For a security issue, use the repository's private vulnerability reporting mechanism if the maintainer has enabled it. Do not post exploitable payloads or credentials in a public issue. Maintainers should enable GitHub private vulnerability reporting before inviting security submissions.

The local development server binds to 127.0.0.1. The optional browser smoke script launches a temporary Chrome profile with a localhost debugging port; use it only in a trusted development or CI environment.

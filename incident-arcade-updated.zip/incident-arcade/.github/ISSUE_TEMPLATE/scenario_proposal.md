---
name: Propose an incident
about: A distinct failure mechanism with something useful to learn
title: 'Scenario: '
labels: enhancement
---

## Learning question

What should a user understand after investigating this incident?

## Failure mechanism

What changes, and why does it cause a failure?

## Observable evidence

What can the player inspect without being told the answer?

## Decisions and consequences

Describe plausible interventions and how the model responds.

## Source and simplifications

Link primary sources where relevant. Separate historical facts from invented modeling assumptions.

## Reproducibility

What tests would show that the causal mechanism and recovery are actually modeled?

---
name: Report a bug
about: A broken interaction, incorrect explanation, or reproducibility problem
title: ''
labels: bug
---

## What happened?

## What did you expect?

## Reproduce it

Include a replay JSON or link when relevant. Never include secrets or real customer data.

## Environment

Browser, device, operating system, and whether browser storage is restricted.

## Evidence

Screenshots, console errors, or a failing automated test.

/**
 * A minimal, explicitly non-visual DOM harness for this app's interaction tests.
 * It does NOT emulate CSS layout, browser accessibility, SVG rendering, or audio.
 * Real-browser checks live in scripts/browser-smoke.mjs.
 */
import {readFile} from 'node:fs/promises';
const voidTags=new Set(['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr']);
const decode=text=>text.replace(/&(?:amp|lt|gt|quot|#39|nbsp|#\d+|#x[0-9a-f]+);/gi,m=>{
  const known={'&amp;':'&','&lt;':'<','&gt;':'>','&quot;':'"','&#39;':"'",'&nbsp;':' '};
  return known[m]??String.fromCodePoint(m.startsWith('&#x')?parseInt(m.slice(3),16):parseInt(m.slice(2),10));
});
export class HarnessEvent {
  constructor(type,options={}){this.type=type;this.bubbles=options.bubbles??false;this.defaultPrevented=false;Object.assign(this,options);}
  preventDefault(){this.defaultPrevented=true;}
}
class Events {
  constructor(){this.listeners=new Map();}
  addEventListener(type,fn){if(!this.listeners.has(type))this.listeners.set(type,[]);this.listeners.get(type).push(fn);}
  dispatchEvent(event){if(!event.target)event.target=this;for(const fn of this.listeners.get(event.type)||[])fn(event);return!event.defaultPrevented;}
}
export class HarnessElement extends Events {
  constructor(tag,owner){super();this.tagName=tag.toUpperCase();this.ownerDocument=owner;this.attributes=new Map();this.children=[];this.parentElement=null;this.style={};this._value='';this.checked=false;this.disabled=false;this.hidden=false;this.open=false;
    this.classList={contains:name=>this.className.split(/\s+/).includes(name),toggle:(name,force)=>{const set=new Set(this.className.split(/\s+/).filter(Boolean));const add=force??!set.has(name);add?set.add(name):set.delete(name);this.className=[...set].join(' ');return add;},add:(...names)=>{for(const n of names)this.classList.toggle(n,true);},remove:(...names)=>{for(const n of names)this.classList.toggle(n,false);}};
    this.dataset=new Proxy({}, {get:(_,key)=>this.getAttribute('data-'+String(key).replace(/[A-Z]/g,c=>'-'+c.toLowerCase()))??undefined,set:(_,key,value)=>{this.setAttribute('data-'+String(key).replace(/[A-Z]/g,c=>'-'+c.toLowerCase()),value);return true;}});
  }
  get id(){return this.getAttribute('id')||'';}set id(v){this.setAttribute('id',v);}
  get className(){return this.getAttribute('class')||'';}set className(v){this.setAttribute('class',v);}
  get value(){return this._value;}set value(v){this._value=String(v);}
  get textContent(){return this.children.map(c=>typeof c==='string'?c:c.textContent).join('');}
  set textContent(v){this.children=[String(v)];}
  get innerHTML(){return this._html||'';}
  set innerHTML(html){this._html=String(html);this.children=[];parse(this._html,this,this.ownerDocument);}
  setAttribute(name,value){this.attributes.set(name,String(value));if(name==='value')this._value=String(value);if(name==='hidden')this.hidden=true;if(name==='disabled')this.disabled=true;}
  getAttribute(name){return this.attributes.get(name)??null;}
  removeAttribute(name){this.attributes.delete(name);if(name==='hidden')this.hidden=false;if(name==='disabled')this.disabled=false;}
  append(...items){for(const item of items){if(typeof item!=='string')item.parentElement=this;this.children.push(item);}}
  remove(){if(this.parentElement)this.parentElement.children=this.parentElement.children.filter(c=>c!==this);}
  matches(selector){return selector.split(',').some(part=>matches(this,part.trim()));}
  closest(selector){let node=this;while(node){if(node.matches(selector))return node;node=node.parentElement;}return null;}
  querySelectorAll(selector){return descendants(this).filter(el=>el.matches(selector));}
  querySelector(selector){return this.querySelectorAll(selector)[0]||null;}
  focus(){this.ownerDocument.activeElement=this;}
  select(){}
  scrollIntoView(){this.ownerDocument.lastScrolled=this.id;}
  getBoundingClientRect(){return{left:0,top:0,right:1000,bottom:1000,width:1000,height:1000};}
  showModal(){this.open=true;}close(){this.open=false;}
  pauseAnimations(){this.animationsPaused=true;}unpauseAnimations(){this.animationsPaused=false;}
  click(){if(this.disabled)return;this.dispatchEvent(new HarnessEvent('click',{bubbles:true}));}
  dispatchEvent(event){super.dispatchEvent(event);if(event.bubbles){if(this.parentElement)this.parentElement.dispatchEvent(event);else this.ownerDocument.dispatchEvent(event);}return!event.defaultPrevented;}
}
function descendants(root){const out=[];for(const c of root.children){if(typeof c==='string')continue;out.push(c,...descendants(c));}return out;}
function simpleMatch(el,selector){
  const tag=selector.match(/^[a-z][\w-]*/i)?.[0];if(tag&&el.tagName!==tag.toUpperCase())return false;
  const id=selector.match(/#([\w-]+)/)?.[1];if(id&&el.id!==id)return false;
  for(const m of selector.matchAll(/\.([\w-]+)/g))if(!el.classList.contains(m[1]))return false;
  for(const m of selector.matchAll(/\[([^\]=]+)(?:=["']?([^\]"']*)["']?)?\]/g)){
    const actual=el.getAttribute(m[1]);if(actual===null||(m[2]!==undefined&&actual!==m[2]))return false;
  }
  return true;
}
function matches(el,selector){
  const parts=selector.split(/\s+(?![^\[]*\])/);if(!simpleMatch(el,parts.pop()))return false;
  let ancestor=el.parentElement;
  while(parts.length){const part=parts.pop();while(ancestor&&!simpleMatch(ancestor,part))ancestor=ancestor.parentElement;if(!ancestor)return false;ancestor=ancestor.parentElement;}
  return true;
}
function parse(html,parent,owner){
  const stack=[parent];
  for(const token of html.match(/<!--[\s\S]*?-->|<![^>]*>|<[^>]*>|[^<]+/g)||[]) {
    if(token.startsWith('<!'))continue;
    if(token.startsWith('</')){const tag=token.slice(2).replace(/\s*>$/,'').toUpperCase();while(stack.length>1){const top=stack.pop();if(top.tagName===tag)break;}continue;}
    if(token.startsWith('<')){
      const tag=token.match(/^<([\w:-]+)/)?.[1];if(!tag)continue;
      const el=new HarnessElement(tag,owner);
      const attrs=token.slice(tag.length+1).replace(/\/?\s*>$/,'');
      for(const a of attrs.matchAll(/([^\s=]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s]+)))?/g))el.setAttribute(a[1],decode(a[2]??a[3]??a[4]??''));
      stack.at(-1).append(el);if(!voidTags.has(tag)&&!token.endsWith('/>'))stack.push(el);
    }else stack.at(-1).append(decode(token));
  }
}
export async function installDOM() {
  const html=await readFile(new URL('../../index.html',import.meta.url),'utf8');
  const doc=new Events();doc.children=[];doc.hidden=false;doc.activeElement=null;
  doc.getElementById=id=>descendants(doc).find(el=>el.id===id)||null;
  doc.querySelectorAll=selector=>descendants(doc).filter(el=>el.matches(selector));doc.querySelector=selector=>doc.querySelectorAll(selector)[0]||null;
  doc.createElement=tag=>new HarnessElement(tag,doc);doc.append=el=>{if(typeof el!=='string')el.parentElement=null;doc.children.push(el);};
  parse(html,doc,doc);doc.body=doc.querySelector('body');doc.documentElement=doc.querySelector('html');
  // The document is an event target, not an Element parent.
  for(const el of doc.children)if(typeof el!=='string')el.parentElement=null;
  globalThis.document=doc;globalThis.Element=HarnessElement;globalThis.Event=HarnessEvent;globalThis.MouseEvent=HarnessEvent;
  globalThis.window=globalThis;globalThis.innerWidth=1440;const windowEvents=new Events();
  globalThis.addEventListener=(...args)=>windowEvents.addEventListener(...args);globalThis.dispatchEvent=event=>windowEvents.dispatchEvent(event);
  globalThis.matchMedia=()=>({matches:false,addEventListener(){}});
  globalThis.Worker=class{constructor(){throw new Error('No worker in non-visual DOM harness');}};
  const data=new Map();globalThis.localStorage={getItem:key=>data.get(key)??null,setItem:(key,value)=>data.set(key,String(value)),removeItem:key=>data.delete(key)};
  globalThis.location=new URL('http://localhost:5173/');globalThis.history={replaceState:(_state,_title,url)=>{globalThis.location=new URL(url,globalThis.location);}};
  Object.defineProperty(globalThis,'navigator',{configurable:true,value:{clipboard:{async writeText(value){doc.copied=value;}}}});
  let frame;globalThis.requestAnimationFrame=fn=>{frame=fn;return 1;};
  // Toast timeouts need no real clock for these tests.
  globalThis.setTimeout=()=>1;globalThis.clearTimeout=()=>{};
  return{doc,data,async click(selector){const el=doc.querySelector(selector);if(!el)throw new Error('Missing '+selector);el.click();await settle();},
    async event(selector,type,props={}){doc.querySelector(selector).dispatchEvent(new HarnessEvent(type,{bubbles:true,...props}));await settle();},
    async frames(count){for(let i=0;i<count;i++)frame(1000+i*250);await settle();}};
}
export async function settle(){for(let i=0;i<8;i++)await new Promise(resolve=>setImmediate(resolve));}

import test from 'node:test';
import assert from 'node:assert/strict';
import {SCENARIOS,newRun,getScenario,optionsFor,capacityAt,arrivalsAt} from '../src/scenario.js';
import {simulate,changePolicy,validateRun,validatePolicy,policyAt} from '../src/engine.js';
import {getEpisode} from '../src/episodes.js';
import {encodeRun,decodeRun} from '../src/replay.js';
import {cleanProgress,recordOutcome,outcomeMessage} from '../src/progress.js';
const experiment=(id,patch={},seed=42)=>simulate(changePolicy(newRun(seed,id),18,{...getScenario(id).initial,...patch}));
for(const scenario of SCENARIOS) {
  test(`${scenario.id}: all authored choices are valid and conserve customer/work accounting`,()=>{
    const e=getEpisode(scenario.id),base=simulate(newRun(42,scenario.id));
    for(const c of e.choices) {
      const r=experiment(scenario.id,c.patch);
      assert.deepEqual(r.frames.map(f=>f.incoming),base.frames.map(f=>f.incoming));
      for(const f of r.frames) {
        assert.equal(f.incoming,f.success+f.failed+f.pending);
        assert.equal(f.attempts,f.processed+f.queue+f.overflow);
        assert.ok(f.queue>=0&&f.queue<=1200);
        assert.ok(f.failed>=f.rejected);
        assert.ok(f.wasted<=f.processed);
      }
    }
  });
  test(`${scenario.id}: replay encodes scenario, policy, and version deterministically`,()=>{
    const r=experiment(scenario.id,getEpisode(scenario.id).choices[0].patch);
    assert.deepEqual(simulate(decodeRun(encodeRun(r.run))),r);
  });
  test(`${scenario.id}: all choices have visible consequences without creating customers`,()=>{
    const baseline=simulate(newRun(42,scenario.id));
    for(const c of getEpisode(scenario.id).choices) {
      const r=experiment(scenario.id,c.patch);
      assert.notDeepEqual(r.frames,baseline.frames,c.id);
      assert.equal(r.summary.incoming,baseline.summary.incoming);
    }
  });
  test(`${scenario.id}: malformed extra policy values are rejected`,()=>{
    for(const key of Object.keys(optionsFor(scenario))) assert.throws(()=>validatePolicy({...scenario.initial,[key]:'bad'},scenario));
  });
}
test('each episode has three simple decisions, three clues, and one unambiguous reflection',()=>{
  for(const s of SCENARIOS) {
    const e=getEpisode(s.id);assert.equal(e.choices.length,3);assert.equal(new Set(e.choices.map(c=>c.id)).size,3);
    assert.equal(Object.keys(e.evidence).length,3);assert.equal(e.answers.length,3);assert.ok(e.correct>=0&&e.correct<3);
    assert.match(e.source,/^https:\/\//);assert.ok(e.caveat.length>80);
  }
});
test('flash sale increases arrivals, not the capacity of an individual worker',()=>{
  const s=getScenario('flash-sale');assert.equal(arrivalsAt(s,9),48);assert.equal(arrivalsAt(s,10),180);assert.equal(arrivalsAt(s,70),48);
  assert.equal(capacityAt(s,18,s.initial),120);assert.equal(capacityAt(s,18,{...s.initial,replicas:2}),240);
});
test('capacity is a real intervention in the flash-sale model',()=>{
  const base=experiment('flash-sale'),scaled=experiment('flash-sale',{replicas:2});
  assert.ok(scaled.summary.success>base.summary.success+5000);assert.ok(scaled.summary.recoveredAt!==null);
});
test('load shedding counts every rejected customer as a failure, not as a success',()=>{
  const base=experiment('flash-sale'),gate=experiment('flash-sale',{admission:50});
  assert.ok(gate.summary.success>base.summary.success);assert.ok(gate.summary.rejected>5000);
  assert.equal(gate.summary.incoming,base.summary.incoming);assert.ok(gate.summary.failed>=gate.summary.rejected);
});
test('a bad release does not repair itself at the retry scenario maintenance boundary',()=>{
  const r=experiment('bad-rollout');assert.equal(r.frames[24].capacity,24);assert.equal(r.frames[89].capacity,24);
});
test('rollback restores capacity but does not delete the existing queue',()=>{
  const r=experiment('bad-rollout',{rollback:true}),base=experiment('bad-rollout');
  assert.equal(r.frames[18].queue,base.frames[18].queue);assert.ok(r.frames[18].queue>0);
  assert.equal(r.frames[19].capacity,120);assert.ok(r.frames[19].queue>0);
  assert.ok(r.summary.success>base.summary.success+3000);
});
test('waiting longer is not falsely a cure for the bad release',()=>{
  const r=experiment('bad-rollout',{timeoutMs:5000});assert.equal(r.frames[89].capacity,24);assert.equal(r.summary.recoveredAt,null);
});
test('scenario-specific policy fields are not required or leaked into retry policies',()=>{
  assert.deepEqual(Object.keys(validatePolicy(getScenario('retry-storm').initial)),['retries','backoff','timeoutMs','admission']);
  assert.equal(policyAt(newRun(42,'flash-sale'),18).replicas,1);
  assert.equal(policyAt(newRun(42,'bad-rollout'),18).rollback,false);
});
test('legacy retry runs normalize safely to the new version',()=>{
  const old={...newRun(),engine:'1.0.0'};assert.deepEqual(simulate(old).frames,simulate(newRun()).frames);
  assert.throws(()=>validateRun({...newRun(42,'flash-sale'),engine:'1.0.0'}));
});
test('missing, inherited, and unknown scenario names do not pass replay validation',()=>{
  for(const scenario of [undefined,null,'__proto__','toString','missing']) assert.throws(()=>validateRun({...newRun(),scenario}));
  assert.throws(()=>getEpisode('__proto__'));
});
test('no-op interventions preserve outcomes for all scenarios',()=>{
  for(const s of SCENARIOS) assert.deepEqual(experiment(s.id).frames,simulate(newRun(42,s.id)).frames);
});
test('cross-scenario switching cannot mutate a previous timeline',()=>{
  const run=experiment('bad-rollout',{rollback:true}).run,saved=JSON.stringify(run);
  experiment('flash-sale',{replicas:2});experiment('retry-storm',{retries:1});assert.equal(JSON.stringify(run),saved);
});
test('the intended causal improvements hold across multiple seeded arrival streams',()=>{
  for(const seed of [1,7,42,2026,4294967295]) {
    for(const [id,patch] of [['retry-storm',{retries:1}],['flash-sale',{replicas:2}],['bad-rollout',{rollback:true}]]) {
      const a=experiment(id,{},seed),b=experiment(id,patch,seed);assert.ok(b.summary.success>a.summary.success,`${id}/${seed}`);
      assert.equal(a.summary.incoming,b.summary.incoming);
    }
  }
});
test('progress is bounded, local-friendly data, and best results only improve',()=>{
  let p=recordOutcome({},'retry-storm',100);p=recordOutcome(p,'retry-storm',50);
  assert.equal(p['retry-storm'].best,100);assert.equal(p['retry-storm'].attempts,2);
  assert.deepEqual(cleanProgress({evil:{best:Infinity}}),{});
  assert.equal(cleanProgress({'flash-sale':{best:Infinity,attempts:-5,understood:'yes'}})['flash-sale'].understood,false);
});
test('outcome copy describes measured differences, not invented skill scores',()=>{
  assert.equal(outcomeMessage({success:15},{success:10}).delta,5);
  assert.equal(outcomeMessage({success:5},{success:10}).improved,false);
  assert.match(outcomeMessage({success:10},{success:10}).detail,/same number/);
});
test('retry animation metrics describe current repeat work, not cumulative history',()=>{
  const flash=experiment('flash-sale');assert.ok(flash.frames.every(f=>f.retryRate===0));
  const stopped=experiment('retry-storm',{retries:0});assert.ok(stopped.frames[18].retryRate>0);
  assert.equal(stopped.frames.at(-1).retryRate,0);assert.ok(stopped.summary.retries>0);
});

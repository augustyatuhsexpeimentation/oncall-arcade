import test from 'node:test';
import assert from 'node:assert/strict';
import {installDOM,settle,HarnessEvent} from './support/dom.mjs';
import {newRun} from '../src/scenario.js';
import {changePolicy} from '../src/engine.js';
import {encodeRun} from '../src/replay.js';
const harness=await installDOM();
await import('../src/app.js');
const {doc,click,event,data}=harness;
const $=id=>doc.getElementById(id);
// These are DOM/state regressions, not browser-layout or real-audio claims.
test('fresh load explains the mission and does not auto-play or create audio',()=>{
  assert.equal(doc.body.dataset.stage,'intro');assert.equal($('time-code').textContent,'T+00:18');
  assert.equal($('audio-summary').textContent,'Audio off');assert.equal($('sound-toggle').checked,false);
  assert.equal($('music-toggle').checked,false);assert.equal($('trial-result').hidden,true);
  assert.equal($('play-button').disabled,false);assert.equal(doc.querySelectorAll('[data-case]').length,3);
});
test('start has a clear next step and inspecting a character records a clue',async()=>{
  await click('#take-pager');assert.equal(doc.body.dataset.stage,'inspect');
  await click('.scene-character[data-evidence="traffic"]');assert.equal($('clue-count').textContent,'1 / 3');
  assert.match($('evidence-panel').textContent,/No extra shoppers/);
  await click('#hint-button');assert.equal($('hint-copy').hidden,false);
  await click('#guide-next');assert.equal(doc.body.dataset.stage,'choose');assert.equal(doc.lastScrolled,'decisions');
});
test('a first decision produces measured results and a visible retry action',async()=>{
  await click('[data-preset="budget"]');assert.equal(doc.body.dataset.stage,'watch');
  await click('#finish-button');assert.equal(doc.body.dataset.stage,'result');assert.equal($('trial-result').hidden,false);
  assert.match($('result-description').textContent,/1,206 more/);assert.match($('result-numbers').textContent,/1,709/);
  assert.equal($('casebook-count').textContent,'1 / 3 explored');
});
test('one-click rewind pins the prior trial and starts a fair fresh branch',async()=>{
  await click('#retry-button');assert.equal(doc.body.dataset.stage,'choose');assert.equal($('time-code').textContent,'T+00:18');
  await click('[data-preset="harder"]');await click('#finish-button');
  assert.match($('result-title').textContent,/Same result/);assert.match($('previous-trial').textContent,/1,709/);
  await click('#result-compare');assert.equal($('modal').open,true);
  assert.deepEqual(doc.querySelectorAll('.big-number').map(el=>el.textContent),['1,709','503']);
  await click('#modal-close');
});
test('reflection offers explanations, not penalties or a locked next level',async()=>{
  await click('[data-answer="1"]');assert.match($('reflection-feedback').textContent,/Not quite/);
  await click('[data-answer="0"]');assert.match($('reflection-feedback').textContent,/Exactly/);
  assert.equal($('next-case-button').disabled,false);
});
test('the next episode changes the simulation, evidence, and decisions',async()=>{
  await click('#next-case-button');assert.equal($('incident-title').textContent,'Everybody wants a tote');
  await click('#tab-traffic');assert.match($('evidence-panel').textContent,/180/);
  await click('#guide-next');await click('[data-preset="scale"]');await click('#finish-button');
  assert.match($('result-numbers').textContent,/10,699/);assert.match($('result-observation').textContent,/not free in real life/);
  assert.equal($('casebook-count').textContent,'2 / 3 explored');
});
test('rollback episode explains safe rollback assumptions and changes capacity',async()=>{
  await click('#next-case-button');assert.equal($('incident-title').textContent,'It worked on my laptop');
  await click('#tab-changes');assert.match($('evidence-panel').textContent,/no schema migration/);
  await click('#guide-next');await click('[data-preset="rollback"]');await click('#finish-button');
  assert.match($('result-numbers').textContent,/4,302/);assert.equal($('casebook-count').textContent,'3 / 3 explored');
  assert.match($('lesson-caveat').textContent,/schema/);
});
test('the end of the casebook is explicit rather than promising endless content',async()=>{
  await click('#next-case-button');assert.equal($('casebook').open,true);assert.equal(doc.lastScrolled,'casebook');
});
test('free play retains manual controls and can return to guided play',async()=>{
  await click('#mode-button');assert.equal(doc.body.classList.contains('guided'),false);
  await click('#rewind-button');$('control-rollback').value='false';$('control-timeout').value='5000';
  await event('#policy-form','submit');await click('#finish-button');assert.match($('result-description').textContent,/same number/);
  await click('#mode-button');assert.equal(doc.body.classList.contains('guided'),true);
});
test('a shared replay selects the correct case and branching clears its old hash',async()=>{
  const run=changePolicy(newRun(42,'flash-sale'),18,{retries:0,backoff:'immediate',timeoutMs:1200,admission:50,replicas:1});
  location.hash=`run=${encodeRun(run)}`;globalThis.dispatchEvent(new HarnessEvent('hashchange'));await settle();
  assert.equal($('incident-title').textContent,'Everybody wants a tote');assert.match($('result-numbers').textContent,/5,056/);
  await click('#retry-button');assert.equal(location.hash,'');
});
test('reduced motion, unavailable audio, and privacy controls do not block play',async()=>{
  await click('#motion-button');assert.equal(doc.body.classList.contains('reduced-motion'),true);
  $('sound-toggle').checked=true;await event('#sound-toggle','change');assert.equal($('sound-toggle').checked,false);
  assert.match($('audio-status').textContent,/unavailable/);
  await click('#privacy-button');await click('[data-modal-action="clear-storage"]');
  assert.equal(data.has('incident-arcade:session:v2'),false);assert.equal($('casebook-count').textContent,'0 / 3 explored');
  await click('#modal-close');
});
test('leaving the tab pauses a running experiment',async()=>{
  await click('[data-preset="scale"]');assert.equal($('play-label').textContent,'Pause');
  doc.hidden=true;doc.dispatchEvent(new HarnessEvent('visibilitychange'));await settle();
  assert.equal($('play-label').textContent,'Play');doc.hidden=false;
});

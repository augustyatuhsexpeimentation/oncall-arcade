import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,mkdtemp,mkdir,cp,writeFile,rm} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {tmpdir} from 'node:os';
import {spawnSync} from 'node:child_process';
const root=resolve(import.meta.dirname,'..');
test('offline preview contains a syntactically valid complete module bundle',async()=>{
  const r=spawnSync(process.execPath,['scripts/standalone.mjs'],{cwd:root,encoding:'utf8'});assert.equal(r.status,0,r.stderr);
  const html=await readFile(resolve(root,'preview.html'),'utf8');
  const script=html.match(/<script type="module">([\s\S]*?)<\/script>/)?.[1];assert.ok(script);
  assert.doesNotMatch(script,/^import\s/m);assert.doesNotMatch(html,/<script[^>]+src=/);
  const syntax=spawnSync(process.execPath,['--input-type=module','--check'],{input:script,encoding:'utf8'});assert.equal(syntax.status,0,syntax.stderr);
});
test('clean static build includes the worker, assets and source-guide fallback',async()=>{
  const r=spawnSync(process.execPath,['scripts/build.mjs'],{cwd:root,encoding:'utf8'});assert.equal(r.status,0,r.stderr);
  for(const file of ['index.html','styles.css','src/worker.js','src/engine.js','assets/social-card.png','docs/README-SOURCE.md','LICENSE','.nojekyll','_headers'])await readFile(resolve(root,'dist',file));
});
test('launch configuration stamps real absolute URLs without touching source logic',async()=>{
  const dir=await mkdtemp(join(tmpdir(),'incident-config-'));
  try{
    await mkdir(join(dir,'scripts'));await mkdir(join(dir,'src'));
    await cp(resolve(root,'scripts/configure.mjs'),join(dir,'scripts/configure.mjs'));
    await writeFile(join(dir,'index.html'),'<html><head></head><body></body></html>');
    await writeFile(join(dir,'README.md'),'<!-- LIVE_LINK_START -->local<!-- LIVE_LINK_END -->');
    const r=spawnSync(process.execPath,['scripts/configure.mjs','--repo','https://github.com/example/incident-arcade','--site','https://example.github.io/incident-arcade'],{cwd:dir,encoding:'utf8'});assert.equal(r.status,0,r.stderr);
    const html=await readFile(join(dir,'index.html'),'utf8');
    assert.match(html,/https:\/\/example.github.io\/incident-arcade\/assets\/social-card.png/);
    assert.match(await readFile(join(dir,'README.md'),'utf8'),/Play the live incident/);
    const again=spawnSync(process.execPath,['scripts/configure.mjs','--repo','https://github.com/example/incident-arcade','--site','https://example.github.io/incident-arcade/'],{cwd:dir,encoding:'utf8'});assert.equal(again.status,0,again.stderr);
    assert.equal((await readFile(join(dir,'index.html'),'utf8')).match(/og:image"/g).length,1);
  }finally{await rm(dir,{recursive:true,force:true});}
});

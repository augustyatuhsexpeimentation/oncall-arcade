import test from 'node:test';
import assert from 'node:assert/strict';
import { simulate, noise, validateRun, validatePolicy, policyAt, changePolicy, policyDescription } from '../src/engine.js';
import { newRun, SCENARIO, OPTIONS, LIMITS } from '../src/scenario.js';

const patch = (values, at = 18, seed = 42) => changePolicy(newRun(seed), at, { ...SCENARIO.initial, ...values });
const baseline = simulate();
const budget = simulate(patch({retries:1}));
const none = simulate(patch({retries:0}));

test('baseline fixture is stable for engine 1.0.0, scenario 1, seed 42', () => {
  assert.equal(baseline.summary.incoming, 4302);
  assert.equal(baseline.summary.success, 503);
  assert.equal(baseline.summary.attempts, 15426);
  assert.equal(baseline.summary.recoveredAt, null);
});
test('same seed, engine, scenario and actions give identical results', () => assert.deepEqual(simulate(), baseline));
test('simulation returns one frame for every integer second including zero', () => {
  assert.equal(baseline.frames.length, 91);
  baseline.frames.forEach((f, i) => assert.equal(f.time, i));
});
test('unique customer outcomes reconcile in every frame', () => {
  for(const f of baseline.frames) assert.equal(f.incoming, f.success + f.failed + f.pending);
});
test('all database attempts reconcile with processed work, queue and overflow', () => {
  for(const f of baseline.frames) assert.equal(f.attempts, f.processed + f.queue + f.overflow);
});
test('bounded queues and customer deadlines constrain resource usage', () => {
  for(const f of baseline.frames){assert.ok(f.queue<=SCENARIO.maxQueue);assert.ok(f.pending<=410);assert.ok(f.queue>=0);}
});
test('success, failure, incoming and attempts are monotonically counted', () => {
  for(let i=1;i<baseline.frames.length;i++) for(const key of ['success','failed','incoming','attempts','retries','processed','wasted']) assert.ok(baseline.frames[i][key]>=baseline.frames[i-1][key]);
});
test('no failures occur before the capacity drop', () => {assert.equal(baseline.frames[9].failed,0);assert.equal(baseline.frames[9].queue,0);});
test('capacity drop and recovery occur at documented boundaries', () => {
  assert.equal(baseline.frames[9].capacity,120);assert.equal(baseline.frames[10].capacity,12);assert.equal(baseline.frames[23].capacity,12);assert.equal(baseline.frames[24].capacity,120);
});
test('the first one-second arrival window includes all arrivals, not a zero bucket', () => assert.equal(baseline.frames[1].arrivalRate,baseline.frames[1].incoming));
test('a no-op policy change does not alter any frames', () => assert.deepEqual(simulate(patch({})).frames,baseline.frames));
test('a one-retry budget reduces attempts and improves customer outcomes', () => {
  assert.ok(budget.summary.success>baseline.summary.success);assert.ok(budget.summary.attempts<baseline.summary.attempts);assert.ok(budget.summary.recoveredAt>24);
});
test('switching off retries allows this modeled queue to drain', () => {
  assert.ok(none.summary.success>budget.summary.success);assert.ok(none.summary.recoveredAt<budget.summary.recoveredAt);assert.equal(none.frames.at(-1).queue,0);
});
test('retrying harder adds work without creating extra customer successes here', () => {
  const r=simulate(patch({retries:6}));assert.ok(r.summary.attempts>baseline.summary.attempts);assert.equal(r.summary.success,baseline.summary.success);
});
test('jitter alone is not falsely presented as a cure for sustained overload', () => {
  const r=simulate(patch({backoff:'jitter'}));assert.equal(r.summary.recoveredAt,null);assert.ok(r.summary.attempts>r.summary.incoming);
});
test('a budget plus longer timeout and jitter improves on a budget alone here', () => {
  const r=simulate(patch({retries:1,backoff:'jitter',timeoutMs:3000}));assert.ok(r.summary.success>budget.summary.success);
});
test('turning off retries from time zero creates no retry attempts', () => {
  const r=simulate(patch({retries:0},0));assert.equal(r.summary.retries,0);assert.equal(r.summary.attempts,r.summary.incoming);
});
test('load shedding never removes incoming customers from outcome accounting', () => {
  const r=simulate(patch({admission:50}));assert.equal(r.summary.incoming,baseline.summary.incoming);assert.ok(r.summary.rejected>1000);assert.ok(r.summary.failed>=r.summary.rejected);
});
test('timed-out backend work still consumes service slots', () => {
  assert.ok(baseline.summary.wasted>5000);assert.ok(baseline.summary.wasted<=baseline.summary.processed);
});
test('all policies see exactly the same arrival stream', () => {
  for(const r of [budget,none,simulate(patch({retries:6,admission:75,backoff:'jitter'}))]) assert.deepEqual(r.frames.map(f=>f.incoming),baseline.frames.map(f=>f.incoming));
});
test('different seeds change the arrival stream', () => assert.notDeepEqual(simulate(newRun(3)).frames.map(f=>f.incoming),baseline.frames.map(f=>f.incoming)));
test('policyAt observes action boundaries', () => {
  const run=patch({retries:1});assert.equal(policyAt(run,17).retries,3);assert.equal(policyAt(run,18).retries,1);
});
test('forking drops future decisions and preserves the pinned run', () => {
  const original=changePolicy(patch({retries:6}),40,{...SCENARIO.initial,timeoutMs:3000});
  const saved=JSON.stringify(original);const branch=changePolicy(original,18,{...SCENARIO.initial,retries:0});
  assert.equal(branch.actions.length,1);assert.equal(branch.actions[0].policy.retries,0);assert.equal(JSON.stringify(original),saved);
});
test('changing a policy at the same time replaces rather than duplicates it', () => {
  const run=changePolicy(patch({retries:1}),18,{...SCENARIO.initial,backoff:'jitter',retries:1});assert.equal(run.actions.length,1);assert.equal(run.actions[0].policy.backoff,'jitter');
});
test('simulation does not mutate inputs', () => {
  const run=patch({retries:1});Object.freeze(run.actions[0].policy);Object.freeze(run.actions[0]);Object.freeze(run.actions);Object.freeze(run);assert.doesNotThrow(()=>simulate(run));
});
test('noise is deterministic and bounded', () => {
  for(let i=0;i<100;i++){const v=noise(42,i,9);assert.ok(v>=0&&v<1);assert.equal(v,noise(42,i,9));}
});
test('policy descriptions contain explicit units', () => assert.match(policyDescription(SCENARIO.initial),/1.2s timeout, 100% admitted/));
test('all allowed enum combinations validate', () => {
  for(const [key,values] of Object.entries(OPTIONS)) for(const value of values) assert.doesNotThrow(()=>validatePolicy({...SCENARIO.initial,[key]:value}));
});
test('invalid policy values are rejected', () => {
  for(const p of [null,[],{}, {...SCENARIO.initial,retries:999},{...SCENARIO.initial,admission:0},{...SCENARIO.initial,backoff:'eval()'}]) assert.throws(()=>validatePolicy(p));
});
test('malformed runs, versions and seeds are rejected before simulation', () => {
  for(const value of [null,[],{}, {...newRun(),format:2},{...newRun(),engine:'999'},{...newRun(),scenario:'unknown'},{...newRun(),scenarioVersion:2},...[-1,0,1.2,NaN,Infinity,4294967296,'42'].map(seed=>({...newRun(),seed}))]) assert.throws(()=>validateRun(value));
});
test('seed boundaries are accepted', () => {assert.equal(validateRun(newRun(1)).seed,1);assert.equal(validateRun(newRun(4294967295)).seed,4294967295);});
test('action times reject duplicates, descending order, non-integers and out-of-range values', () => {
  for(const times of [[18,18],[30,10],[-1],[90],[1.5],['18']]) assert.throws(()=>validateRun({...newRun(),actions:times.map(at=>({at,policy:SCENARIO.initial}))}));
});
test('replay action count is bounded', () => {
  assert.doesNotThrow(()=>validateRun({...newRun(),actions:Array.from({length:LIMITS.maxActions},(_,at)=>({at,policy:SCENARIO.initial}))}));
  assert.throws(()=>validateRun({...newRun(),actions:Array.from({length:65},(_,at)=>({at,policy:SCENARIO.initial}))}));
});
test('unknown imported fields are discarded, never evaluated', () => {
  const r=validateRun({...newRun(),html:'<script>alert(1)</script>',__proto__:{polluted:true}});assert.equal(r.html,undefined);assert.equal({}.polluted,undefined);
});
test('you cannot intervene after the simulation ends', () => assert.throws(()=>changePolicy(newRun(),90,SCENARIO.initial)));
test('invariants survive multiple seeds and changing policies', () => {
  for(const seed of [1,7,42,2026,4294967295]){
    let run=newRun(seed);
    [8,18,35,62].forEach((at,i)=>{run=changePolicy(run,at,{retries:OPTIONS.retries[(seed+i)%4],backoff:i%2?'jitter':'immediate',timeoutMs:OPTIONS.timeoutMs[i],admission:OPTIONS.admission[i%3]});});
    const r=simulate(run);
    for(const f of r.frames){assert.equal(f.incoming,f.success+f.failed+f.pending);assert.equal(f.attempts,f.processed+f.queue+f.overflow);assert.ok(f.queue<=1200);assert.ok(f.pending>=0);assert.ok(f.availability===null||(f.availability>=0&&f.availability<=1));}
    assert.deepEqual(r.frames.map(f=>f.incoming),simulate(newRun(seed)).frames.map(f=>f.incoming));
  }
});

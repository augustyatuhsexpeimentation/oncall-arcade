import test from 'node:test';
import assert from 'node:assert/strict';
import {ArcadeAudio,noteHz,FX,MUSIC_NOTES,MUSIC_BPM} from '../src/audio.js';
class Parameter {constructor(){this.value=0;}setValueAtTime(){}linearRampToValueAtTime(){}exponentialRampToValueAtTime(){}setTargetAtTime(){}cancelScheduledValues(){}}
class Context {
  constructor(){this.state='suspended';this.currentTime=1;this.destination={};this.started=[];}
  createGain(){return{gain:new Parameter(),connect(){},disconnect(){}};}
  createOscillator(){const ctx=this;return{frequency:{value:0},connect(){},disconnect(){},start(at){ctx.started.push({at,note:this.frequency.value});},stop(){queueMicrotask(()=>this.onended?.());}};}
  async resume(){this.state='running';}async suspend(){this.state='suspended';}async close(){this.state='closed';}
}
test('audio starts silent and creates no AudioContext before user opt-in',()=>{
  const a=new ArcadeAudio();assert.equal(a.effects,false);assert.equal(a.music,false);assert.equal(a.context,null);assert.equal(a.timer,null);
});
test('original score and effects have finite, bounded musical values',()=>{
  assert.equal(noteHz(69),440);assert.equal(MUSIC_BPM,84);
  for(const notes of MUSIC_NOTES) for(const n of notes) assert.ok(n>=36&&n<=90);
  for(const sequence of Object.values(FX)) for(const [note,delay,duration] of sequence) {
    assert.ok(noteHz(note)>100&&noteHz(note)<2000);assert.ok(delay>=0&&delay<1);assert.ok(duration>0&&duration<1);
  }
});
test('audio features fail gracefully when Web Audio is unavailable',async()=>{
  const previous=globalThis.AudioContext;delete globalThis.AudioContext;
  try{const a=new ArcadeAudio();assert.equal(await a.setEnabled('music',true),false);assert.equal(a.unavailable,true);assert.equal(a.music,false);}finally{globalThis.AudioContext=previous;}
});
test('effects and music are independent controls and can be muted',async()=>{
  globalThis.AudioContext=Context;const a=new ArcadeAudio();
  try {
    await a.setEnabled('effects',true);assert.equal(a.music,false);a.play('clue');assert.equal(a.context.started.length,2);
    await a.setEnabled('effects',false);const count=a.context.started.length;a.play('result');assert.equal(a.context.started.length,count);
    await a.setEnabled('music',true);assert.ok(a.timer);assert.equal(a.effects,false);
    await a.setEnabled('music',false);assert.equal(a.timer,null);
  }finally{await a.dispose();delete globalThis.AudioContext;}
});
test('hiding the tab suspends sound and clears the music scheduler',async()=>{
  globalThis.AudioContext=Context;const a=new ArcadeAudio();
  try{
    await a.setEnabled('music',true);await a.setHidden(true);assert.equal(a.context.state,'suspended');assert.equal(a.timer,null);
    await a.setHidden(false);assert.equal(a.context.state,'running');assert.ok(a.timer);
  }finally{await a.dispose();delete globalThis.AudioContext;}
});
test('volume is bounded and muted effects do not require audio support',async()=>{
  const a=new ArcadeAudio();a.setVolume(-50);assert.equal(a.volume,0);a.setVolume(10);assert.equal(a.volume,1);
  assert.doesNotThrow(()=>a.play('pager'));assert.equal(await a.setEnabled('invalid',true),false);
});
test('a quick off click wins over an earlier pending audio unlock',async()=>{
  let resume;class SlowContext extends Context{resume(){return new Promise(resolve=>{resume=()=>{this.state='running';resolve();};});}}
  globalThis.AudioContext=SlowContext;const a=new ArcadeAudio();
  try{const enabling=a.setEnabled('music',true);await a.setEnabled('music',false);resume();await enabling;assert.equal(a.music,false);assert.equal(a.timer,null);}finally{await a.dispose();delete globalThis.AudioContext;}
});

/** Set this to your public repository URL before launch. No secrets belong here. */
export const SITE = Object.freeze({
  repository: '',
  author: 'Incident Arcade contributors',
});

import { SCENARIOS, newRun, LIMITS, getScenario } from './scenario.js';
import { simulate, validateRun, policyAt, changePolicy, policyDescription } from './engine.js';
import { parseRun, decodeRun, replayURL } from './replay.js';
import { mountScene, updateScene } from './scene.js';
import { downloadBlob, downloadShareCard } from './share-card.js';
import { SITE } from './site-config.js';
import { getEpisode } from './episodes.js';
import { ArcadeAudio } from './audio.js';
import { cleanProgress, recordOutcome, outcomeMessage } from './progress.js';

const $=id=>document.getElementById(id);
const esc=text=>String(text).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const number=n=>n.toLocaleString('en-US');
const percent=n=>n===null?'--':`${Math.round(n*100)}%`;
const clock=s=>`${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;
const STORAGE_KEY='incident-arcade:session:v2';
const reducedQuery=matchMedia('(prefers-reduced-motion: reduce)');
const stages=['intro','inspect','choose','watch','result'];
function initialState(id='retry-storm',seed=42) {
  return {run:newRun(seed,id),reference:newRun(seed,id),time:18,visited:18,clues:[],selected:'',
    reduced:reducedQuery.matches,speed:4,mode:'guided',stage:'intro',lastChoice:'',lastFinished:'',volume:35};
}
let state=initialState(),progress={};
let result,referenceResult,baselineResult;
let busy=false,playing=false,computeVersion=0,lastPolicy='',toastTimer,storageAllowed=true,initialNotice='';
let episodeKey='',casebookKey='',resultKey='',lastFrame=0,elapsed=0;
class EngineClient {
  constructor() {
    this.worker = null; this.pending = new Map(); this.counter = 0; this.cache = new Map();
    try {
      this.worker = new Worker(new URL('./worker.js', import.meta.url), { type: 'module' });
      this.worker.onmessage = ({ data }) => {
        const task = this.pending.get(data.id); if (!task) return;
        this.pending.delete(data.id);
        if (data.error) task.reject(new Error(data.error)); else task.resolve(data.result);
      };
      this.worker.onerror = () => {
        this.worker?.terminate(); this.worker = null;
        for (const task of this.pending.values()) {
          try { task.resolve(simulate(task.run)); } catch (error) { task.reject(error); }
        }
        this.pending.clear();
      };
    } catch { this.worker = null; }
  }
  async calculate(run) {
    const clean = validateRun(run), key = JSON.stringify(clean);
    if (this.cache.has(key)) return this.cache.get(key);
    const data = this.worker ? await new Promise((resolve, reject) => {
      const id = ++this.counter; this.pending.set(id, { resolve, reject, run: clean });
      this.worker.postMessage({ id, run: clean });
    }) : simulate(clean);
    this.cache.set(key, data);
    if (this.cache.size > 16) this.cache.delete(this.cache.keys().next().value);
    return data;
  }
}
const engine=new EngineClient();
const audio=new ArcadeAudio(renderAudio);
const scenario=()=>getScenario(state.run.scenario);
const episode=()=>getEpisode(state.run.scenario);

function restore() {
  try {
    const raw=localStorage.getItem(STORAGE_KEY);
    if(raw&&raw.length<90000) {
      const saved=JSON.parse(raw);progress=cleanProgress(saved.progress);
      const run=validateRun(saved.run),reference=validateRun(saved.reference);
      if(reference.seed!==run.seed||reference.scenario!==run.scenario) throw new Error('Invalid comparison');
      const time=Number.isInteger(saved.time)?Math.max(0,Math.min(90,saved.time)):18;
      state={...initialState(run.scenario,run.seed),run,reference,time,
        visited:Number.isInteger(saved.visited)?Math.max(time,Math.min(90,saved.visited)):time,
        clues:Array.isArray(saved.clues)?[...new Set(saved.clues.filter(k=>['traffic','database','changes'].includes(k)))]:[],
        selected:['traffic','database','changes'].includes(saved.selected)?saved.selected:'',
        reduced:typeof saved.reduced==='boolean'?saved.reduced:reducedQuery.matches,
        speed:[1,2,4].includes(saved.speed)?saved.speed:4,mode:saved.mode==='free'?'free':'guided',
        stage:stages.includes(saved.stage)?saved.stage:'inspect',
        lastChoice:typeof saved.lastChoice==='string'?saved.lastChoice.slice(0,100):'',
        lastFinished:typeof saved.lastFinished==='string'?saved.lastFinished.slice(0,24000):'',
        volume:Number.isFinite(saved.volume)?Math.max(0,Math.min(100,saved.volume)):35};
      if(state.time===90) state.stage='result';
      else if(state.stage==='result') state.stage='choose';
      initialNotice='Your local progress is here. Audio stays off until you turn it on.';
    }
  } catch { /* Private mode, corrupt data, or unavailable storage must not block play. */ }
  if(location.hash.startsWith('#run=')) {
    try {
      const run=decodeRun(location.hash.slice(5));
      state={...initialState(run.scenario,run.seed),run,reference:newRun(run.seed,run.scenario),time:90,visited:90,stage:'result'};
      initialNotice='Replay loaded. These are the recorded decisions, not a live website outage.';
    } catch(error) {initialNotice=error.message;}
  }
  audio.setVolume(state.volume/100);
}
function save() {
  if(!storageAllowed) return;
  try {localStorage.setItem(STORAGE_KEY,JSON.stringify({...state,progress}));}
  catch {storageAllowed=false;toast('Saving is unavailable in this browser. You can still play and export a run.');}
}
function clearHash() {try {history.replaceState(null,'',location.pathname+location.search);} catch {}}
function toast(text) {
  clearTimeout(toastTimer);$('toast').textContent=text;$('toast').hidden=false;
  toastTimer=setTimeout(()=>{$('toast').hidden=true;},5500);
}
function scrollToPart(id,focus=false) {
  const element=$(id);element.scrollIntoView({behavior:state.reduced?'instant':'smooth',block:'start'});
  if(focus) element.focus({preventScroll:true});
}
function pause() {playing=false;lastFrame=0;elapsed=0;if(result) render();}
function start() {
  if(!result||busy||state.time>=90) return;
  playing=true;lastFrame=0;elapsed=0;render();
}
function openModal(html) {
  pause();$('modal-body').innerHTML=html;
  if(!$('modal').open) $('modal').showModal();
  $('modal-close').focus();
}
function closeModal() {$('modal').close();}
async function recompute(all=false) {
  const version=++computeVersion;busy=true;renderTransport();
  try {
    const outputs=await Promise.all([
      engine.calculate(state.run),
      all||!referenceResult?engine.calculate(state.reference):referenceResult,
      all||!baselineResult?engine.calculate(newRun(state.run.seed,state.run.scenario)):baselineResult,
    ]);
    if(version!==computeVersion) return false;
    [result,referenceResult,baselineResult]=outputs;busy=false;render();save();return true;
  } catch(error) {
    if(version!==computeVersion) return false;
    busy=false;playing=false;toast(`Could not run this experiment: ${error.message}`);renderTransport();return false;
  }
}
function renderAudio() {
  $('sound-toggle').checked=audio.effects;$('music-toggle').checked=audio.music;
  $('audio-summary').textContent=audio.effects||audio.music?'Audio on':'Audio off';
  $('audio-volume').value=String(state.volume);$('volume-label').textContent=`${state.volume}%`;
  $('audio-status').textContent=audio.unavailable?'Audio is unavailable here. The entire game still works without it.':'';
}
function renderCasebook() {
  const key=JSON.stringify([state.run.scenario,progress]);if(key===casebookKey) return;casebookKey=key;
  const completed=Object.values(progress).filter(p=>p.attempts>0).length;
  $('casebook-count').textContent=`${completed} / 3 explored`;
  $('case-list').innerHTML=SCENARIOS.map(s=>{
    const e=getEpisode(s.id),p=progress[s.id];
    return `<button class="case-card" data-case="${s.id}" aria-current="${s.id===state.run.scenario}"><span class="eyebrow">CASE ${e.number} / ${e.difficulty}</span><strong>${esc(e.label)}</strong><small>${esc(e.hook)}</small><span class="case-status">${p?.attempts?`Explored ${p.attempts} ${p.attempts===1?'time':'times'}${p.understood?' / lesson checked':''}`:'Ready when you are'}</span></button>`;
  }).join('');
}
function renderEpisode() {
  if(episodeKey===state.run.scenario) return;
  episodeKey=state.run.scenario;const s=scenario(),e=episode();
  $('incident-title').textContent=s.title;document.querySelector('.case-number').textContent=e.number;
  $('decision-grid').innerHTML=e.choices.map(c=>`<button class="decision-card" data-preset="${c.id}"><span class="decision-icon" aria-hidden="true">${esc(c.icon)}</span><span class="decision-title">${esc(c.title)}</span><span class="decision-copy">${esc(c.copy)}</span><span class="decision-arrow" aria-hidden="true">&#8599;</span></button>`).join('');
  $('replica-control').hidden=s.kind!=='surge';$('release-control').hidden=s.kind!=='release';
}
function renderGuide() {
  const e=episode(),stage=state.stage;
  document.body.classList.toggle('guided',state.mode==='guided');document.body.dataset.stage=stage;
  $('mode-button').textContent=state.mode==='guided'?'Free play':'Guided play';
  $('mode-button').setAttribute('aria-pressed',String(state.mode==='free'));
  const info={
    intro:['A tiny shop needs your help.',e.mission,"Let's investigate"],
    inspect:['First, find a clue.',`${e.setup} Tap a character or a notebook tab. Time is paused.`, 'Choose a fix'],
    choose:['What would you change?', 'Pick one idea below. You do not have to be right: a wrong turn is something you can rewind.', 'Show my choices'],
    watch:[playing?'Watch your idea play out.':'Your experiment is paused.',playing?'Watch the line and the customer outcomes. You can skip ahead; the same 90 seconds will still be simulated.':'Resume when you are ready. The experiment does not change while you are away.',playing?'See the result now':'Continue the experiment'],
    result:['Now try a different decision.','Same incident. Same incoming customers. A fair comparison, not a lucky second attempt.','Try a different fix'],
  }[stage];
  if(state.mode==='free') {
    $('guide-title').textContent='Free play: follow your own hunch.';
    $('guide-copy').textContent='The timeline, manual controls, journal, and exports are open. Changes take effect at the current playhead. Switch back to Guided play any time.';
    $('guide-next').textContent=state.time>=90?'Rewind & try again':'See the full result';
  } else { $('guide-title').textContent=info[0];$('guide-copy').textContent=info[1];$('guide-next').textContent=info[2]; }
  $('guide-next').disabled=busy||!result;
  $('hint-button').hidden=!['inspect','choose'].includes(stage)||state.mode==='free';
  $('step-look').classList.toggle('active',['intro','inspect'].includes(stage));
  $('step-try').classList.toggle('active',['choose','watch'].includes(stage));
  $('step-compare').classList.toggle('active',stage==='result');
  $('take-pager').innerHTML=stage==='intro'?'Play my first incident <span aria-hidden="true">&#8594;</span>':'Continue investigating <span aria-hidden="true">&#8594;</span>';
  $('player-dock').hidden=state.mode!=='guided'||stage==='intro';
  $('dock-label').textContent=stage==='watch'?'A 90-second experiment':stage==='result'?'Same incident. New decision.':'Look. Try. Learn.';
  $('dock-next').textContent=info[2];$('dock-next').disabled=busy||!result;
}
function renderEvidence() {
  if(!result) return;
  const f=result.frames[state.time],e=episode();
  $('clue-count').textContent=`${state.clues.length} / 3`;
  document.querySelectorAll('.evidence-tabs button').forEach(button=>{
    const selected=button.dataset.evidence===state.selected;
    button.setAttribute('aria-selected',String(selected));button.classList.toggle('seen',state.clues.includes(button.dataset.evidence));
    button.tabIndex=selected||(!state.selected&&button.dataset.evidence==='traffic')?0:-1;
  });
  if(!state.selected) {
    $('evidence-panel').removeAttribute('aria-labelledby');
    $('evidence-panel').innerHTML=`<p class="note-number">YOUR FIRST CLUE IS A CLICK AWAY</p><h3>${esc(e.hook)}</h3><p>Tap the customers, the server, or the database. Each has something to tell you.</p><div class="note-prompt">No terminal. No trick questions.<br>Just a little curiosity.</div>`;return;
  }
  $('evidence-panel').setAttribute('aria-labelledby',`tab-${state.selected}`);
  const clue=e.evidence[state.selected],index=['traffic','database','changes'].indexOf(state.selected)+1;
  const metric=state.selected==='traffic'?`${Math.round(f.arrivalRate)}<span class="evidence-unit">new customers / second, last 5s</span>`:state.selected==='database'?`${number(f.queue)}<span class="evidence-unit">waiting attempts / capacity ${f.capacity} per second</span>`:`+10s<span class="evidence-unit">when the incident begins</span>`;
  $('evidence-panel').innerHTML=`<p class="note-number">CLUE 0${index} / ${esc(state.selected.toUpperCase())}</p><h3>${esc(clue.title)}</h3><p>${esc(clue.body)}</p><span class="evidence-stat">${metric}</span><div class="note-prompt">${esc(clue.question)}</div>`;
}
function spark(id,key,max) {
  const data=result.frames.slice(Math.max(0,state.time-30),state.time+1);
  const points=data.map((f,i)=>`${(i/Math.max(1,data.length-1)*98+1).toFixed(1)},${(30-Math.min(1,(f[key]??0)/max)*27).toFixed(1)}`).join(' ');
  $(id).innerHTML=`<path d="M1 31H99" stroke="#dddccd" fill="none"/><polyline points="${points}" fill="none" stroke="${key==='availability'?'#34786b':'#b98661'}" stroke-width="1.7" stroke-linejoin="round"/>`;
}
function renderTransport() {
  $('play-label').textContent=busy?'Thinking':playing?'Pause':'Play';$('play-symbol').textContent=playing?'\u2161':'\u25b6';
  $('play-button').setAttribute('aria-label',playing?'Pause simulation':'Play simulation');
  $('timeline').max=String(state.visited);$('timeline').value=String(state.time);$('timeline-label').textContent=`${state.time} / 90s`;
  $('timeline').setAttribute('aria-valuetext',`${state.time} simulated seconds. Furthest explored: ${state.visited} seconds.`);
  $('speed').value=String(state.speed);$('motion-button').setAttribute('aria-pressed',String(state.reduced));
  $('motion-button').textContent=state.reduced?'Motion off':'Motion';document.body.classList.toggle('reduced-motion',state.reduced);
  for(const id of ['play-button','step-button','finish-button','pin-button','compare-button','debrief-button','share-button','export-button','take-pager','import-button','rewind-button','retry-button','next-case-button','result-compare','result-share','result-image','mode-button']) $(id).disabled=busy||!result;
  $('step-button').disabled=busy||!result||state.time>=90;$('finish-button').disabled=busy||!result||state.time>=90;
  document.querySelectorAll('[data-preset], #policy-form button').forEach(button=>{button.disabled=busy||!result||state.time>=90;});
  document.querySelectorAll('[data-case]').forEach(button=>{button.disabled=busy;});
  if(result) updateScene(result.frames[state.time],playing,state.reduced,state.selected);
}
function renderResult() {
  const visible=state.stage==='result'&&state.time===90&&!!result;
  $('trial-result').hidden=!visible;if(!visible) {resultKey='';return;}
  const key=JSON.stringify([state.run,state.reference]);if(key===resultKey) return;resultKey=key;
  const current=result.summary,base=baselineResult.summary,e=episode(),outcome=outcomeMessage(current,base);
  $('result-title').textContent=state.run.actions.length?outcome.headline:'This is the no-change baseline.';
  $('result-description').textContent=state.run.actions.length?`${outcome.detail} Compared with doing nothing.`:'Now change one decision and see whether it helps.';
  $('result-numbers').innerHTML=`<div class="result-number"><span>Doing nothing</span><strong>${number(base.success)}</strong><small>successful checkouts<br>${number(base.failed)} failed / ${number(base.pending)} pending</small></div><div class="result-number current"><span>Your decision</span><strong>${number(current.success)}</strong><small>successful checkouts<br>${number(current.failed)} failed / ${number(current.pending)} pending</small></div><div class="result-number"><span>Same incoming customers</span><strong>${number(current.incoming)}</strong><small>Equal 90-second windows.<br>Rejected customers count as failures.</small></div>`;
  const policy=policyAt(state.run,89);
  let observation=outcome.improved?'Your change helped more customers in this modeled incident. Open the explanation to see why.':'The experiment still taught you something. Rewind and test another idea; no lives or real servers are on the line.';
  if(scenario().kind==='surge'&&policy.replicas===2) observation+=' You used two database workers instead of one; that extra capacity is not free in real life.';
  if(current.rejected) observation+=` ${number(current.rejected)} customers were turned away and counted as failures.`;
  $('result-observation').textContent=observation;
  const previous=referenceResult.summary.success;$('previous-trial').hidden=!state.reference.actions.length;
  $('previous-trial').textContent=`Your previous try completed ${number(previous)} checkouts. This try completed ${number(current.success)}. The detailed comparison keeps both timelines.`;
  $('lesson-title').textContent=e.lessonTitle;$('lesson-copy').textContent=e.lesson;$('lesson-caveat').textContent=e.caveat;
  $('lesson-source').href=e.source;$('lesson-source').textContent=e.sourceLabel;
  $('reflection-question').textContent=`One question to take with you: ${e.question}`;
  $('reflection-options').innerHTML=e.answers.map((answer,i)=>`<button class="answer-button" data-answer="${i}" aria-pressed="false">${esc(answer)}</button>`).join('');
  $('reflection-feedback').textContent='';$('lesson-details').open=false;
  const index=SCENARIOS.findIndex(s=>s.id===state.run.scenario);
  $('next-case-button').textContent=index<SCENARIOS.length-1?'Next incident \u2192':'Back to the casebook \u2192';
}
function render() {
  if(!result) return;
  renderEpisode();renderCasebook();const f=result.frames[state.time];
  const healthy=f.availability!==null&&f.availability>=.95&&f.queue<60;
  $('time-code').textContent=`T+${clock(state.time)}`;$('seed-label').textContent=`SEED ${state.run.seed}`;
  $('status-text').textContent=state.time>=90?'Experiment complete':playing?(healthy?'Checkout is flowing':'Testing your idea'):'Paused. Look around.';
  $('status-badge').classList.toggle('healthy',healthy);
  $('story-text').textContent=state.time<10?'A quiet evening. Everything is working. For now.':healthy?'The checkout is flowing. Which decision helped, and what did it cost?':episode().story;
  $('metric-success').textContent=percent(f.availability);$('metric-queue').textContent=number(f.queue);
  $('metric-amplification').textContent=`${f.amplification.toFixed(1)}\u00d7`;$('metric-traffic').textContent=String(Math.round(f.arrivalRate));
  spark('spark-success','availability',1);spark('spark-queue','queue',1200);spark('spark-attempts','amplification',7);
  $('timeline-markers').innerHTML=state.run.actions.filter(a=>a.at<=state.visited).map(a=>`<span class="timeline-marker" style="left:${a.at/Math.max(1,state.visited)*100}%"></span>`).join('');
  const policy=policyAt(state.run,state.time),key=JSON.stringify(policy);
  $('current-policy').textContent=policyDescription(policy);
  if(key!==lastPolicy) {
    $('control-retries').value=String(policy.retries);$('control-backoff').value=policy.backoff;
    $('control-timeout').value=String(policy.timeoutMs);$('control-admission').value=String(policy.admission);
    $('control-replicas').value=String(policy.replicas??1);$('control-rollback').value=String(policy.rollback??false);lastPolicy=key;
  }
  const events=result.logs.filter(e=>e.at<=state.time).slice(-7);
  $('journal-list').innerHTML=events.map(e=>`<li class="${e.kind==='decision'?'decision-event':''}"><span class="event-time">+${String(e.at).padStart(2,'0')}s</span><span>${esc(e.text)}</span></li>`).join('');
  const count=state.run.actions.filter(a=>a.at<=state.time).length;$('journal-count').textContent=`${count} ${count===1?'decision':'decisions'}`;
  $('pinned-label').textContent=state.reference.actions.length?'Reference: your previous pinned try.':'Reference: doing nothing.';
  renderGuide();renderEvidence();renderTransport();renderResult();renderAudio();
}
function beginMission() {
  if(busy||!result) return;
  if(state.stage==='intro') {state.stage='inspect';audio.play('pager');render();save();}
  scrollToPart(state.stage==='result'?'trial-result':state.stage==='choose'?'decisions':'playground',true);
}
function guideNext() {
  if(busy||!result) return;
  if(state.mode==='free') {state.time>=90?retryExperiment():finishRun();return;}
  if(state.stage==='intro') return beginMission();
  if(state.stage==='inspect') {state.stage='choose';render();save();scrollToPart('decisions',true);return;}
  if(state.stage==='choose') return scrollToPart('decisions',true);
  if(state.stage==='watch') return playing?finishRun():start();
  retryExperiment();
}
function inspect(name) {
  if(!['traffic','database','changes'].includes(name)||!result||busy) return;
  if(state.stage==='intro') state.stage='inspect';
  const fresh=!state.clues.includes(name);state.selected=name;if(fresh) state.clues.push(name);
  if(fresh) audio.play('clue');render();save();
  if(window.innerWidth<601) $('evidence-panel').scrollIntoView({behavior:state.reduced?'instant':'smooth',block:'nearest'});
}
async function applyPolicy(policy,label='Your own policy') {
  if(busy||!result||state.time>=90) return;
  pause();
  try {
    clearHash();const at=state.time;state.run=changePolicy(state.run,at,policy);state.visited=at;lastPolicy='';
    state.stage='watch';state.lastChoice=label;state.lastFinished='';resultKey='';
    if(!(await recompute())) return;
    $('decision-feedback').textContent=`At +${at}s: ${label} ${policyDescription(policy)}.`;
    audio.play('choose');start();scrollToPart('playground',true);
  } catch(error) {toast(error.message);}
}
function setTime(time) {
  if(busy||!result) return;
  pause();state.time=Math.max(0,Math.min(state.visited,time));state.stage=state.time>=90?'result':'choose';lastPolicy='';
  $('decision-feedback').textContent=`At +${state.time}s. A new decision replaces later decisions in this branch. The pinned timeline stays safe.`;
  render();save();
}
function finishRun(reveal=true) {
  if(busy||!result) return;
  playing=false;lastFrame=0;elapsed=0;state.time=90;state.visited=90;state.stage='result';
  const signature=JSON.stringify(state.run);
  if(state.run.actions.length&&state.lastFinished!==signature) {
    // Best outcomes in the casebook are deliberately tied to the default seed.
    if(state.run.seed===42) progress=recordOutcome(progress,state.run.scenario,result.summary.success);
    state.lastFinished=signature;audio.play('result');
  }
  render();save();if(reveal) scrollToPart('trial-result',true);
}
async function retryExperiment() {
  if(busy||!result) return;
  playing=false;clearHash();state.reference=validateRun(state.run);state.run=newRun(state.run.seed,state.run.scenario);
  state.time=18;state.visited=18;state.stage='choose';state.lastChoice='';state.lastFinished='';lastPolicy='';resultKey='';
  $('hint-copy').hidden=true;
  if(await recompute(true)) {audio.play('rewind');scrollToPart('decisions',true);}
}
async function pinRun() {
  if(busy||!result) return;
  pause();state.reference=validateRun(state.run);referenceResult=await engine.calculate(state.reference);resultKey='';render();save();
  toast('This full timeline is pinned. Rewind and change a decision.');
}
async function switchEpisode(id) {
  if(busy) return;
  getScenario(id);playing=false;const reduced=state.reduced,volume=state.volume,mode=state.mode;
  state={...initialState(id),reduced,volume,mode,stage:'inspect'};lastPolicy='';episodeKey='';resultKey='';
  $('casebook').open=false;$('hint-copy').hidden=true;clearHash();
  if(await recompute(true)) {audio.play('pager');scrollToPart('playground',true);}
}
function nextCase() {
  const index=SCENARIOS.findIndex(s=>s.id===state.run.scenario);
  if(index<SCENARIOS.length-1) switchEpisode(SCENARIOS[index+1].id);
  else {$('casebook').open=true;scrollToPart('casebook');toast('That is the last case. Choose any case to replay, or use Free play to test your own policies.');}
}
function comparisonCard(summary,title,current=false) {
  return `<div class="comparison-card ${current?'current':''}"><h3>${esc(title)}</h3><div class="big-number">${number(summary.success)}</div><div class="small-caption">successful / ${number(summary.incoming)} incoming</div><dl class="comparison-stats"><div><dt>Failed customers</dt><dd>${number(summary.failed)}</dd></div><div><dt>Still pending at 90s</dt><dd>${number(summary.pending)}</dd></div><div><dt>Rejected (included in failures)</dt><dd>${number(summary.rejected)}</dd></div><div><dt>Database attempts</dt><dd>${number(summary.attempts)}</dd></div><div><dt>Peak queue</dt><dd>${number(summary.peakQueue)}</dd></div><div><dt>First stable recovery</dt><dd>${summary.recoveredAt===null?'Not within 90s':`+${summary.recoveredAt}s`}</dd></div></dl></div>`;
}
function chartLine(frames) {
  return frames.filter(f=>f.availability!==null).map((f,i)=>`${i?'L':'M'}${(42+f.time/90*586).toFixed(2)} ${(138-f.availability*108).toFixed(2)}`).join(' ');
}
function comparisonChart(a,b) {
  return `<svg class="comparison-chart" viewBox="0 0 660 170" role="img" aria-label="Success among resolved customers over time. A data table follows."><path d="M42 30H628M42 84H628M42 138H628" stroke="#d4d8c9"/><g fill="#596452" font-family="monospace" font-size="10"><text x="5" y="33">100%</text><text x="12" y="87">50%</text><text x="18" y="141">0%</text><text x="41" y="158">0s</text><text x="230" y="158">30s</text><text x="424" y="158">60s</text><text x="609" y="158">90s</text></g><path d="${chartLine(a.frames)}" stroke="#a68765" stroke-width="2.5" fill="none" stroke-dasharray="5 4"/><path d="${chartLine(b.frames)}" stroke="#34786b" stroke-width="2.5" fill="none"/></svg><div class="chart-legend"><span>Reference timeline</span><span>Your current timeline</span></div><details><summary>Read the chart as a table</summary><table class="comparison-table"><thead><tr><th>Time</th><th>Reference success</th><th>Your success</th><th>Your queue</th></tr></thead><tbody>${b.frames.filter(f=>f.time%10===0).map(f=>`<tr><td>+${f.time}s</td><td>${percent(a.frames[f.time].availability)}</td><td>${percent(f.availability)}</td><td>${number(f.queue)}</td></tr>`).join('')}</tbody></table></details>`;
}
function openComparison() {
  if(!result||!referenceResult) return;
  const delta=result.summary.success-referenceResult.summary.success;
  openModal(`<p class="eyebrow">${esc(episode().label.toUpperCase())} / A FAIR COMPARISON</p><h2 id="modal-title">Two timelines.<br>The same customers.</h2><p>Both timelines cover the same <strong>90 simulated seconds</strong>, even if you have not watched all of them. Incoming customers and incident conditions match. Only your recorded policies differ.</p><div class="comparison-grid">${comparisonCard(referenceResult.summary,state.reference.actions.length?'Your previous / pinned try':'Doing nothing')}${comparisonCard(result.summary,'Your current try',true)}</div><div class="outcome-delta">${delta===0?'The same number of customers completed checkout.':`${number(Math.abs(delta))} ${delta>0?'more':'fewer'} customers completed checkout.`}</div><p>The chart shows success among resolved operations over the last 5s. The cards count all incoming customers; failures, rejections, and pending customers stay visible.</p>${comparisonChart(referenceResult,result)}<p class="model-warning">Recovery: five consecutive observations with at least 95% recent success and fewer than 60 queued attempts. For the retry case, recovery is measured after maintenance ends. This is a teaching threshold, not a real service guarantee.</p><div class="modal-actions"><button class="button button-teal" data-modal-action="image">Save result image</button><button class="button button-outline" data-modal-action="share">Copy replay link</button><button class="button button-outline" data-modal-action="debrief">Read the explanation</button></div>`);
}
function assumptionsHTML() {
  return `<p>All three cases use one bounded, first-in-first-out queue and 100ms time steps. Each attempt takes one modeled service slot. Customers wait at most 8s overall. The queue holds at most 1,200 attempts; excess attempts are rejected.</p><p>Queued work remains after a caller times out. Already queued attempts keep their original timeout; a policy change does not erase work. The flash-sale case doubles capacity instantly when a second worker is chosen. The release case models a reversible, code-only query regression.</p><p>Real networks, database locks, cache misses, payment side effects, cancellation, rollout delays, financial cost, and non-linear scaling are not simulated. These are three small teaching experiments, not replicas of a cloud environment. The same version, scenario, seed, and decisions reproduce the same result.</p>`;
}
function openDebrief() {
  const e=episode();
  openModal(`<p class="eyebrow">A LESSON, NOT A SCORE OF YOUR ABILITY</p><h2 id="modal-title">${esc(e.lessonTitle)}</h2><p>${esc(e.lesson)}</p><p class="model-warning">${esc(e.caveat)}</p><h3>Try the opposite.</h3><p>Keep this run, rewind, and make a different choice. Compare completed customer checkouts, not just a green status light.</p><details><summary>What the model leaves out</summary>${assumptionsHTML()}</details><p><a href="${e.source}" target="_blank" rel="noopener noreferrer">${esc(e.sourceLabel)}</a>. The fictional workload and numerical results are not measurements from this source.</p><div class="modal-actions"><button class="button button-teal" data-modal-action="retry">Try another approach</button><button class="button button-outline" data-modal-action="compare">Compare timelines</button></div>`);
}
function openHow() {
  openModal(`<p class="eyebrow">NO CODING NEEDED. NO REAL SERVERS.</p><h2 id="modal-title">You are the on-call human.</h2><p>Your shop is struggling. Your goal is to help more customers finish checkout than would succeed if you did nothing.</p><ol><li><strong>Look:</strong> tap a character or notebook tab for a clue. Time starts paused.</li><li><strong>Try:</strong> choose one plain-language fix. Watch it play out, or skip to the result.</li><li><strong>Compare:</strong> see the full 90-second outcome. Rewind to try another choice with the same incoming customers.</li></ol><p>There are three short incidents. All are unlocked. Free play opens manual controls, the timeline, and the journal. Audio is optional and starts off. Your progress stays in this browser.</p><p><strong>Keyboard:</strong> Tab and Enter operate controls. Arrow keys switch notebook tabs. Escape closes dialogs. Space pauses playback and R rewinds when focus is not inside another control.</p><div class="modal-actions"><button class="button button-teal" data-modal-action="play">Start investigating</button></div>`);
}
function openAbout() {
  openModal(`<p class="eyebrow">THE IDEA BEHIND THE TOY</p><h2 id="modal-title">Make a guess.<br>Watch what happens.</h2><p>Incident Arcade is an open-source educational game, not a debugging tool. Three authored incidents teach retry amplification, overload tradeoffs, and a reversible bad release.</p><p>The learning-through-play direction is inspired by <a href="https://ncase.me/" target="_blank" rel="noopener noreferrer">Nicky Case</a> and <a href="https://neal.fun/" target="_blank" rel="noopener noreferrer">Neal.fun</a>. This project is not affiliated with either creator; their artwork and code were not copied.</p><p>The original illustrated characters remain. Sound effects and the quiet 84 BPM background loop are synthesized locally from openly available source code. No third-party recordings, music subscriptions, or audio downloads are needed.</p><p>The code, original artwork, and procedural score are included under the project's MIT license. No login, runtime dependencies, paid APIs, or backend are required.</p><div class="modal-actions"><button class="button button-outline" data-modal-action="privacy">Privacy and model limits</button></div>`);
}
function openPrivacy() {
  openModal(`<p class="eyebrow">YOUR BROWSER IS THE WHOLE ARCADE</p><h2 id="modal-title">Small model. Clear boundaries.</h2><p>The app makes no analytics, advertising, font, model-API, or tracking requests. A static host can still receive normal asset requests and keep its own access logs.</p><p>The run, previous timeline, notebook, case progress, motion choice, and volume are saved locally when storage is available. Audio switches start off on every page load. Imported runs are validated as data, never executed as code.</p><p>A replay link contains the scenario, seed, engine version, and decisions in the URL fragment. Anyone you send it to can inspect it. There are no accounts, tamper-proof scores, or global rankings.</p>${assumptionsHTML()}<div class="modal-actions"><button class="button button-outline" data-modal-action="clear-storage">Clear saved progress</button></div>`);
}
async function shareRun() {
  if(!result) return;
  if(location.protocol==='file:') {toast('Replay links need a live website. You can export this run from Free play, or save its result image.');return;}
  const url=replayURL(state.run,location.href);
  try {
    if(!navigator.clipboard?.writeText) throw new Error('Clipboard unavailable');
    await navigator.clipboard.writeText(url);toast('Replay link copied. It shares your decisions, not your saved progress.');
  } catch {
    openModal(`<p class="eyebrow">SHARE YOUR EXPERIMENT</p><h2 id="modal-title">Copy the replay link.</h2><p>Your browser did not allow automatic copying. Select this text and copy it.</p><textarea readonly id="manual-share" aria-label="Replay URL">${esc(url)}</textarea>`);
    $('manual-share').focus();$('manual-share').select();
  }
  if(['localhost','127.0.0.1'].includes(location.hostname)) toast('This is a local link. Publish the site before sharing it publicly.');
}
function exportRun() {
  downloadBlob(new Blob([JSON.stringify(validateRun(state.run),null,2)+'\n'],{type:'application/json'}),`incident-arcade-${state.run.scenario}-${state.run.seed}.json`);
  toast('Run exported. Import it later to replay the same decisions.');
}
async function loadRun(run) {
  playing=false;const reduced=state.reduced,volume=state.volume;
  state={...initialState(run.scenario,run.seed),run,reference:newRun(run.seed,run.scenario),time:90,visited:90,stage:'result',reduced,volume};
  lastPolicy='';episodeKey='';resultKey='';$('hint-copy').hidden=true;
  await recompute(true);
}
async function importRun(file) {
  if(!file) return;pause();
  try {
    if(file.size>LIMITS.maxRunBytes) throw new Error('Choose a JSON run smaller than 24 KB.');
    const run=parseRun(await file.text());await loadRun(run);clearHash();scrollToPart('trial-result',true);toast('Run imported. Rewind to try your own decision.');
  } catch(error) {toast(error.message);}
  $('import-file').value='';
}
function confirmReset() {
  openModal(`<p class="eyebrow">A CLEAN PAGE FOR THIS CASE</p><h2 id="modal-title">Start this incident over?</h2><p>Your current and pinned timelines will be reset. Your overall case progress stays. Free play lets you export a run before resetting.</p><div class="modal-actions"><button class="button button-dark" data-modal-action="reset">Start this case over</button><button class="button button-outline" data-modal-action="close">Keep investigating</button></div>`);
}
async function reset() {
  closeModal();storageAllowed=true;await switchEpisode(state.run.scenario);
  $('decision-feedback').textContent='Time is paused. Take a look, then test an idea.';
}

// Interaction handlers are bound once; generated content uses event delegation.
$('take-pager').addEventListener('click',beginMission);
$('guide-next').addEventListener('click',guideNext);$('dock-next').addEventListener('click',guideNext);
$('hint-button').addEventListener('click',()=>{$('hint-copy').hidden=false;$('hint-copy').textContent=episode().hint;audio.play('clue');});
$('mode-button').addEventListener('click',()=>{
  pause();state.mode=state.mode==='guided'?'free':'guided';
  if(state.stage==='intro') state.stage='inspect';
  if(state.mode==='free') $('metrics-details').open=true;
  render();save();
});
$('play-button').addEventListener('click',()=>playing?pause():start());
$('step-button').addEventListener('click',()=>{pause();state.time=Math.min(90,state.time+1);state.visited=Math.max(state.visited,state.time);state.time>=90?finishRun(false):(render(),save());});
$('speed').addEventListener('change',event=>{state.speed=Number(event.target.value);save();});
$('timeline').addEventListener('input',event=>setTime(Number(event.target.value)));
$('finish-button').addEventListener('click',()=>finishRun());
$('pin-button').addEventListener('click',()=>{pinRun().catch(error=>toast(error.message));});
$('rewind-button').addEventListener('click',()=>{setTime(Math.min(18,state.visited));audio.play('rewind');});
$('retry-button').addEventListener('click',()=>{retryExperiment().catch(error=>toast(error.message));});
$('next-case-button').addEventListener('click',nextCase);
$('compare-button').addEventListener('click',openComparison);$('result-compare').addEventListener('click',openComparison);
$('debrief-button').addEventListener('click',openDebrief);$('how-button').addEventListener('click',openHow);
$('about-button').addEventListener('click',openAbout);$('privacy-button').addEventListener('click',openPrivacy);
$('reset-button').addEventListener('click',confirmReset);$('modal-close').addEventListener('click',closeModal);
$('modal').addEventListener('click',event=>{if(event.target===$('modal')){const r=$('modal').getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom) closeModal();}});
$('motion-button').addEventListener('click',()=>{state.reduced=!state.reduced;render();save();});
reducedQuery.addEventListener('change',event=>{state.reduced=event.matches;render();save();});
for(const id of ['share-button','result-share']) $(id).addEventListener('click',()=>{shareRun().catch(error=>toast(error.message));});
$('result-image').addEventListener('click',async()=>{try{await downloadShareCard(baselineResult.summary,result.summary);toast('Result image saved. It compares your run with doing nothing.');}catch(error){toast(error.message);}});
$('export-button').addEventListener('click',exportRun);$('import-button').addEventListener('click',()=>$('import-file').click());
$('import-file').addEventListener('change',event=>{importRun(event.target.files[0]);});
$('sound-toggle').addEventListener('change',async event=>{const wanted=event.target.checked;await audio.setEnabled('effects',wanted);if(wanted) audio.play('clue');});
$('music-toggle').addEventListener('change',async event=>{await audio.setEnabled('music',event.target.checked);});
$('audio-volume').addEventListener('input',event=>{state.volume=Number(event.target.value);audio.setVolume(state.volume/100);renderAudio();save();});
$('policy-form').addEventListener('submit',event=>{
  event.preventDefault();const policy={...policyAt(state.run,state.time),retries:Number($('control-retries').value),backoff:$('control-backoff').value,timeoutMs:Number($('control-timeout').value),admission:Number($('control-admission').value)};
  if(scenario().kind==='surge') policy.replicas=Number($('control-replicas').value);
  if(scenario().kind==='release') policy.rollback=$('control-rollback').value==='true';
  applyPolicy(policy);
});
document.addEventListener('click',event=>{
  if(!(event.target instanceof Element)) return;
  const evidence=event.target.closest('[data-evidence]');if(evidence) inspect(evidence.dataset.evidence);
  const choice=event.target.closest('[data-preset]');
  if(choice) {const preset=episode().choices.find(c=>c.id===choice.dataset.preset);if(preset) applyPolicy({...policyAt(state.run,state.time),...preset.patch},preset.title);}
  const card=event.target.closest('[data-case]');if(card) switchEpisode(card.dataset.case).catch(error=>toast(error.message));
  const answer=event.target.closest('[data-answer]');
  if(answer) {
    const selected=Number(answer.dataset.answer),e=episode();
    if(!Number.isInteger(selected)||selected<0||selected>=e.answers.length) return;
    document.querySelectorAll('[data-answer]').forEach(button=>button.setAttribute('aria-pressed',String(button===answer)));
    $('reflection-feedback').textContent=`${selected===e.correct?'Exactly.':'Not quite.'} ${e.explanation}`;
    if(selected===e.correct) {audio.play('answer');progress[state.run.scenario]={...(progress[state.run.scenario]||{attempts:0,best:0}),understood:true};renderCasebook();save();}
  }
  if(!event.target.closest('#audio-panel')) $('audio-panel').open=false;
});
document.addEventListener('keydown',event=>{
  const target=event.target;if(!(target instanceof Element)) return;
  if(target.matches('.scene-character')&&['Enter',' '].includes(event.key)) {event.preventDefault();inspect(target.dataset.evidence);return;}
  if(target.matches('[role="tab"]')&&['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) {
    const keys=['traffic','database','changes'],index=keys.indexOf(target.dataset.evidence);
    const next=event.key==='Home'?0:event.key==='End'?2:(index+(event.key==='ArrowRight'?1:2))%3;
    event.preventDefault();inspect(keys[next]);$(`tab-${keys[next]}`).focus();return;
  }
  if(event.key==='Escape'&&$('audio-panel').open) {$('audio-panel').open=false;$('audio-summary').focus();return;}
  if($('modal').open||busy||target.closest('input,select,textarea,button,a,summary,[contenteditable="true"]')) return;
  if(event.code==='Space'&&state.stage==='watch') {event.preventDefault();playing?pause():start();}
  if(event.key.toLowerCase()==='r'&&state.stage!=='intro') {event.preventDefault();if(state.mode==='guided') retryExperiment();else setTime(Math.min(18,state.visited));}
});
$('modal-body').addEventListener('click',async event=>{
  const action=event.target.closest('[data-modal-action]')?.dataset.modalAction;
  try {
    if(action==='image') {await downloadShareCard(referenceResult.summary,result.summary);toast('Comparison image saved.');}
    if(action==='share') await shareRun();
    if(action==='debrief') openDebrief();if(action==='compare') openComparison();if(action==='privacy') openPrivacy();
    if(action==='play') {closeModal();beginMission();}
    if(action==='retry') {closeModal();await retryExperiment();}
    if(action==='close') closeModal();if(action==='reset') await reset();
    if(action==='clear-storage') {
      storageAllowed=false;progress={};try{localStorage.removeItem(STORAGE_KEY);localStorage.removeItem('incident-arcade:session:v1');}catch{}
      renderCasebook();toast('Saved progress cleared. This tab will not save again until you reload or start fresh.');
    }
  } catch(error) {toast(error.message);}
});
document.addEventListener('visibilitychange',()=>{if(document.hidden){pause();save();}audio.setHidden(document.hidden);});
window.addEventListener('pagehide',()=>{save();audio.setHidden(true);});
window.addEventListener('pageshow',()=>{if(!document.hidden) audio.setHidden(false);});
window.addEventListener('hashchange',async()=>{
  if(!location.hash.startsWith('#run=')) return;
  try {await loadRun(decodeRun(location.hash.slice(5)));toast('Shared replay loaded.');}catch(error){toast(error.message);}
});
function animate(now) {
  requestAnimationFrame(animate);
  if(!playing||busy||!result){lastFrame=0;return;}
  if(!lastFrame){lastFrame=now;return;}
  elapsed+=Math.min(250,now-lastFrame)*state.speed;lastFrame=now;
  if(elapsed>=1000) {
    const seconds=Math.floor(elapsed/1000);elapsed%=1000;
    state.time=Math.min(90,state.time+seconds);state.visited=Math.max(state.visited,state.time);
    if(state.time>=90) finishRun();else {render();save();}
  }
}
mountScene($('scene'));restore();renderCasebook();renderAudio();
if(location.protocol==='file:'&&!SITE.repository) {$('source-link').removeAttribute('target');$('source-link').href='#';$('source-link').addEventListener('click',event=>{event.preventDefault();openAbout();});}
if(SITE.repository&&/^https:\/\/github\.com\/[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+\/?$/.test(SITE.repository)) $('source-link').href=SITE.repository;
requestAnimationFrame(animate);
await recompute(true);
if(initialNotice) toast(initialNotice);

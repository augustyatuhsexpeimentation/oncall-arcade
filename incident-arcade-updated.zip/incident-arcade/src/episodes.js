/** Authored teaching content. The engine, not this copy, decides the outcomes. */
export const EPISODES = Object.freeze({
  'retry-storm': {
    number:'01', label:'The retry storm', difficulty:'Start here',
    hook:'The shop is quiet. The database is not.',
    mission:'Help more customers finish checkout. Start by finding where the extra work comes from.',
    setup:'A request is one customer asking to check out. A retry asks again. The original request may still be waiting.',
    clue:'traffic', hint:'Customer traffic is steady. Look at how many times each customer is asking the database.',
    story:'Same customers. Slower checkout. Something is multiplying the work.',
    choices:[
      {id:'harder',icon:'++',title:'Ask again. And again.',copy:'Allow up to 6 retries when a request times out.',patch:{retries:6}},
      {id:'budget',icon:'1x',title:'Ask fewer times.',copy:'Allow just 1 retry. Leave the original work room to finish.',patch:{retries:1}},
      {id:'backoff',icon:'...',title:'Space the retries out.',copy:'Wait a little between attempts instead of retrying immediately.',patch:{backoff:'jitter'}},
    ],
    evidence:{
      traffic:{title:'No extra shoppers.',body:'Traffic stays near 48 new checkouts a second. The crowd is not the cause of all the extra work.',question:'One customer can send more than one attempt.'},
      database:{title:'Still working on the first one.',body:'A caller giving up does not cancel the work already in the database queue. Repeated attempts join the same line.',question:'Busy is not the same as useful.'},
      changes:{title:'A short slowdown. A longer mess.',body:'At +10s, maintenance cuts capacity from 120 to 12 attempts/s. It ends at +24s. No application release changed.',question:'The slowdown ends. The queued work does not.'},
    },
    lessonTitle:'A retry is more work, not a reset.',
    lesson:'Here, timed-out work keeps its place in the queue. Extra attempts can keep demand above capacity even after the original slowdown ends. A retry limit reduces that feedback loop; backoff alone does not guarantee recovery.',
    caveat:'This is one queue, not a real payment processor. It does not model duplicate charges, cancellation, idempotency, network failures, or the cases where retries are necessary.',
    question:'Why can another retry make this incident worse?',
    answers:['The old request is still using the same queue.','Every retry creates a new customer.','Retries permanently slow down the database.'],correct:0,
    explanation:'The customer is the same; the backend attempt is new. If old work stays queued, another attempt adds pressure without necessarily helping that customer.',
    source:'https://aws.amazon.com/builders-library/timeouts-retries-and-backoff-with-jitter/',sourceLabel:'AWS: timeouts, retries, and backoff',
  },
  'flash-sale': {
    number:'02',label:'The flash crowd',difficulty:'A different problem',
    hook:'Your little tote bag went viral. Your shop did not.',
    mission:'Keep as many checkouts working as possible when the sale brings more shoppers than the database can handle.',
    setup:'Capacity means how much work the system can finish each second. Here the crowd grows, but capacity stays the same.',
    clue:'traffic',hint:'Compare new customers per second with the database capacity. This time the crowd really did get bigger.',
    story:'The sale is live. More shoppers arrive each second than one database can serve.',
    choices:[
      {id:'scale',icon:'2x',title:'Add a second worker.',copy:'Double database capacity. This toy makes it available immediately.',patch:{replicas:2}},
      {id:'gate',icon:'1/2',title:'Let half the crowd in.',copy:'Protect the queue, but turn away half of new customers.',patch:{admission:50}},
      {id:'harder',icon:'++',title:'Keep asking.',copy:'Allow 6 retries. Maybe a later attempt will find space.',patch:{retries:6}},
    ],
    evidence:{
      traffic:{title:'The tote bag is a hit.',body:'At +10s, new checkouts jump from 48 to 180 per second. The sale lasts until +70s. The incoming crowd is identical in every replay.',question:'180 customers. 120 service slots. What gives?'},
      database:{title:'A worker, not a magician.',body:'One database worker can finish 120 attempts a second. A growing queue means customers can time out before their turn.',question:'A longer line does not add capacity.'},
      changes:{title:'No broken release this time.',body:'The sale announcement is the change. The application and each worker are unchanged. There are no automatic retries initially.',question:'Do not solve yesterday\'s incident by habit.'},
    },
    lessonTitle:'A smaller queue can still mean lost customers.',
    lesson:'Rejecting some arrivals can preserve useful work for others; rejected shoppers still count as failures. More capacity can serve more demand here, but it uses more resources. Retrying does not create capacity.',
    caveat:'Two workers double capacity immediately in this toy. Real scaling can take time, cost money, encounter shared bottlenecks, or fail to scale linearly. No real servers are created.',
    question:'Why count the customers you turned away?',
    answers:['They do not matter once the graph turns green.','They still tried to buy something and could not.','They automatically succeed on a different server.'],correct:1,
    explanation:'A healthy-looking queue is not the goal by itself. Rejected, failed, and pending customers all remain visible so dropping requests cannot fake success.',
    source:'https://sre.google/sre-book/handling-overload/',sourceLabel:'Google SRE: handling overload',
  },
  'bad-rollout': {
    number:'03',label:'The bad release',difficulty:'Follow the evidence',
    hook:'A tiny update. An impressively untiny problem.',
    mission:'Find what changed, then fix the cause rather than just making the symptoms quieter.',
    setup:'A release is a new version of the app. A rollback brings back the previous version. Find the evidence before choosing a fix.',
    clue:'changes',hint:'Read Changes. Did the number of customers change, or did the cost of serving them change?',
    story:'A new release landed. Checkouts slowed down, even though the crowd stayed the same.',
    choices:[
      {id:'wait',icon:'5s',title:'Wait a little longer.',copy:'Give each attempt a 5-second timeout. Keep the new release.',patch:{timeoutMs:5000}},
      {id:'rollback',icon:'v1',title:'Undo the new release.',copy:'Restore the earlier, cheaper query. Existing work still has to drain.',patch:{rollback:true}},
      {id:'gate',icon:'1/2',title:'Let fewer people in.',copy:'Admit half of new checkouts. Keep the expensive query.',patch:{admission:50}},
    ],
    evidence:{
      traffic:{title:'The same old crowd.',body:'About 48 customers arrive each second, before and after the problem starts. There is no flash sale.',question:'The customer count did not explain the slowdown.'},
      database:{title:'Each checkout got more expensive.',body:'The new query leaves effective capacity at 24 attempts/s instead of 120. The database did not suddenly gain five times as many shoppers.',question:'Fewer retries cannot repair a bad query.'},
      changes:{title:'Version 2 arrived at +10s.',body:'The slowdown starts with the release. Version 2 uses a costlier query. This fictional release has no schema migration, so a rollback is modeled as safe.',question:'A clue, not proof in every real incident.'},
    },
    lessonTitle:'Fix the cause, not just the traffic light.',
    lesson:'The new release reduces effective capacity. Returning to the previous query restores it in this model. A timeout or retry change can alter symptoms, but cannot remove this particular regression.',
    caveat:'Rollback is instant and safe only because this scenario assumes a reversible code-only change. Real deployments can involve irreversible data or schema changes. Verify rollback safety in real systems.',
    question:'What makes rollback useful in this particular case?',
    answers:['Every outage is fixed by rolling back.','Rollback cancels all queued work.','The new code introduced a reversible capacity regression.'],correct:2,
    explanation:'The evidence points to a reversible query change. The queue still drains normally. Real incidents require checking causality and rollback safety, not pressing rollback by habit.',
    source:'https://sre.google/workbook/canarying-releases/',sourceLabel:'Google SRE: canarying releases',
  },
});
export function getEpisode(id) {
  if (!Object.hasOwn(EPISODES,id)) throw new Error('Unknown episode.');
  return EPISODES[id];
}

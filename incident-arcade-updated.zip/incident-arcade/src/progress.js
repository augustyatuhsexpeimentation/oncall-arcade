/** Completion is exploration, not a credential or engineering-skill score. */
import { SCENARIOS } from './scenario.js';
export function cleanProgress(value) {
  const out={};
  if(!value||typeof value!=='object') return out;
  for(const scenario of SCENARIOS) {
    const entry=value[scenario.id];if(!entry||typeof entry!=='object') continue;
    out[scenario.id]={attempts:Number.isSafeInteger(entry.attempts)?Math.max(0,Math.min(100000,entry.attempts)):0,
      best:Number.isSafeInteger(entry.best)?Math.max(0,Math.min(20000,entry.best)):0,
      understood:entry.understood===true};
  }
  return out;
}
export function recordOutcome(progress,id,success) {
  if(!SCENARIOS.some(s=>s.id===id)) throw new Error('Unknown incident.');
  const next=cleanProgress(progress),old=next[id]||{attempts:0,best:0,understood:false};
  next[id]={...old,attempts:Math.min(100000,old.attempts+1),best:Math.max(old.best,Math.max(0,Math.min(20000,Math.trunc(success))))};
  return next;
}
export function outcomeMessage(current,baseline) {
  const delta=current.success-baseline.success;
  return {delta,improved:delta>0,headline:delta>0?'That helped.':delta<0?'A useful wrong turn.':'More activity. Same result.',
    detail:delta>0?`${delta.toLocaleString('en-US')} more customers completed checkout.`:delta<0?`${(-delta).toLocaleString('en-US')} fewer customers completed checkout.`:'The same number of customers completed checkout.'};
}

import { LIMITS } from './scenario.js';
import { validateRun } from './engine.js';

export function parseRun(text) {
  if (typeof text !== 'string' || text.length > LIMITS.maxRunBytes) throw new Error('Run file is too large (maximum 24 KB).');
  let value;
  try { value = JSON.parse(text); } catch { throw new Error('This is not valid JSON. Choose an Incident Arcade run file.'); }
  return validateRun(value);
}
export function encodeRun(run) {
  const json = JSON.stringify(validateRun(run));
  // The validated schema contains only ASCII, numbers, and fixed enum strings.
  return btoa(json).replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/, '');
}
export function decodeRun(encoded) {
  if (typeof encoded !== 'string' || encoded.length > LIMITS.maxLinkLength || !/^[A-Za-z0-9_-]+$/.test(encoded)) throw new Error('Invalid or oversized replay link.');
  try {
    const raw = encoded.replaceAll('-', '+').replaceAll('_', '/');
    return parseRun(atob(raw + '='.repeat((4 - raw.length % 4) % 4)));
  } catch (error) {
    throw new Error(`Cannot open this replay: ${error.message}`);
  }
}
export function replayURL(run, base) {
  const url = new URL(base);
  url.hash = `run=${encodeRun(run)}`;
  return url.href;
}

import { ENGINE_VERSION, SCENARIO, LIMITS, newRun, getScenario, optionsFor, capacityAt, arrivalsAt } from './scenario.js';

/**
 * A bounded, deterministic, discrete-time teaching model.
 * Time advances in 100 ms ticks. Backend work survives client timeouts.
 * Unique customer operations and backend attempts are counted separately.
 * No clocks, IO, DOM, Math.random(), or third-party packages live in this file.
 */
const STEP_MS = 100;
const TICKS_PER_SECOND = 1000 / STEP_MS;
const own = (object, key) => Object.prototype.hasOwnProperty.call(object, key);

/** Counter-based random value: decisions cannot perturb the arrival stream. */
export function noise(seed, counter, salt = 0) {
  let x = (seed ^ Math.imul(counter + 1, 0x9e3779b1) ^ Math.imul(salt + 1, 0x85ebca6b)) >>> 0;
  x ^= x >>> 16;
  x = Math.imul(x, 0x7feb352d);
  x ^= x >>> 15;
  x = Math.imul(x, 0x846ca68b);
  x ^= x >>> 16;
  return (x >>> 0) / 4294967296;
}

export function validatePolicy(value, scenario = SCENARIO) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('A policy must be an object.');
  for (const [key, values] of Object.entries(optionsFor(scenario))) {
    if (!own(value, key) || !values.includes(value[key])) throw new Error(`Unsupported ${key} value.`);
  }
  return Object.fromEntries(Object.keys(optionsFor(scenario)).map(key => [key, value[key]]));
}

/** Reject invalid versions and bound all imported inputs before simulation. */
export function validateRun(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('The run must be a JSON object.');
  if (value.format !== 1 || !(value.engine === ENGINE_VERSION || (value.engine === '1.0.0' && value.scenario === 'retry-storm'))) throw new Error(`This build accepts format 1 / engine ${ENGINE_VERSION} only.`);
  if (typeof value.scenario !== 'string') throw new Error('A scenario identifier is required.');
  const scenario = getScenario(value.scenario);
  if (value.scenarioVersion !== scenario.version) throw new Error('This run uses an unsupported scenario version.');
  if (!Number.isSafeInteger(value.seed) || value.seed < 1 || value.seed > 4294967295) throw new Error('Seed must be an integer from 1 to 4294967295.');
  if (!Array.isArray(value.actions) || value.actions.length > LIMITS.maxActions) throw new Error(`A run can contain at most ${LIMITS.maxActions} decisions.`);
  let previous = -1;
  const actions = value.actions.map(action => {
    if (!action || !Number.isInteger(action.at) || action.at < 0 || action.at >= scenario.duration || action.at <= previous) {
      throw new Error('Decision times must increase, be whole seconds, and fall between 0 and 89.');
    }
    previous = action.at;
    return { at: action.at, policy: validatePolicy(action.policy, scenario) };
  });
  return { ...newRun(value.seed, scenario.id), actions };
}

export function policyAt(run, second) {
  let policy = { ...getScenario(run.scenario).initial };
  for (const action of run.actions) {
    if (action.at > second) break;
    policy = { ...action.policy };
  }
  return policy;
}

/** Forking replaces decisions at/after the chosen time, never the pinned run. */
export function changePolicy(run, second, policy) {
  const clean = validateRun(run);
  if (!Number.isInteger(second) || second < 0 || second >= getScenario(clean.scenario).duration) throw new Error('Rewind before the end to make a decision.');
  return validateRun({ ...clean, actions: [...clean.actions.filter(a => a.at < second), { at: second, policy: validatePolicy(policy, getScenario(clean.scenario)) }] });
}

export function policyDescription(policy) {
  const attempts = policy.retries === 0 ? 'no retries' : `${policy.retries} ${policy.retries === 1 ? 'retry' : 'retries'}`;
  return `${attempts}, ${policy.backoff === 'jitter' ? 'jittered backoff' : 'immediate'}, ${policy.timeoutMs / 1000}s timeout, ${policy.admission}% admitted${policy.replicas ? `, ${policy.replicas}x database capacity` : ''}${typeof policy.rollback === 'boolean' ? (policy.rollback ? ', previous release restored' : ', current release') : ''}`;
}

export function simulate(input = newRun()) {
  const run = validateRun(input);
  const SCENARIO = getScenario(run.scenario);
  const ticks = SCENARIO.duration * TICKS_PER_SECOND;
  const operations = [];
  const active = new Set();
  const queue = [];
  let head = 0;
  const waiting = new Map();
  const scheduled = Array.from({ length: ticks + 82 }, () => []);
  const frames = [];
  const logs = [{ at: 0, kind: 'info', text: 'A quiet checkout service. One customer operation can create several database attempts.' }];
  const buckets = Array.from({ length: SCENARIO.duration + 1 }, () => ({ success: 0, failed: 0, attempts: 0, incoming: 0, retries: 0 }));
  const totals = { incoming: 0, success: 0, failed: 0, rejected: 0, attempts: 0, retries: 0, processed: 0, wasted: 0, timeouts: 0, overflow: 0, maxQueue: 0 };
  let config = { ...SCENARIO.initial };
  let actionIndex = 0;
  let credit = 0;
  let firstTimeout = false;
  let firstOverflow = false;
  let firstAmplification = false;
  let attemptId = 0;
  let currentTick = 0;
  let serviceThisSecond = 0;
  let slotsThisSecond = 0;
  let rollingServed = 0;
  let rollingSlots = 1;

  const secondIndex = () => Math.min(SCENARIO.duration, Math.floor(currentTick / TICKS_PER_SECOND) + 1);
  const finish = (op, status) => {
    if (op.status !== 'pending') return;
    op.status = status;
    active.delete(op.id);
    op.finishedAt = currentTick;
    if (status === 'success') {
      totals.success++;
      buckets[secondIndex()].success++;
    } else {
      totals.failed++;
      buckets[secondIndex()].failed++;
    }
  };

  const failAttempt = (attempt) => {
    const op = operations[attempt.operation];
    if (!op || op.status !== 'pending') return;
    if (currentTick >= op.deadline || op.retries >= config.retries) {
      finish(op, 'failed');
      return;
    }
    op.retries++;
    const capMs = Math.min(3000, 400 * 2 ** (op.retries - 1));
    const delay = config.backoff === 'jitter'
      ? Math.max(1, Math.ceil(noise(run.seed, op.id, op.retries) * capMs / STEP_MS))
      : 1;
    const due = currentTick + delay;
    if (due < op.deadline && due <= ticks) scheduled[due].push(op.id);
    // A retry after the customer's deadline cannot save that customer.
    // The customer remains pending until its original deadline expires.
  };

  const send = (op) => {
    if (op.status !== 'pending' || currentTick >= op.deadline) return;
    const attempt = { id: attemptId++, operation: op.id, expires: currentTick + config.timeoutMs / STEP_MS, timedOut: false };
    totals.attempts++;
    buckets[secondIndex()].attempts++;
    if (op.sent > 0) { totals.retries++; buckets[secondIndex()].retries++; }
    op.sent++;
    if (queue.length - head >= SCENARIO.maxQueue) {
      totals.overflow++;
      if (!firstOverflow) {
        firstOverflow = true;
        logs.push({ at: Math.ceil(currentTick / 10), kind: 'warn', text: 'The database queue hit its 1,200-attempt safety cap. New attempts are being rejected.' });
      }
      failAttempt(attempt);
      return;
    }
    queue.push(attempt);
    waiting.set(attempt.id, attempt);
    totals.maxQueue = Math.max(totals.maxQueue, queue.length - head);
  };

  const frame = (time) => {
    const recent = { success: 0, failed: 0, attempts: 0, incoming: 0, retries: 0 };
    for (let s = Math.max(1, time - 4); s <= time; s++) {
      for (const key of Object.keys(recent)) recent[key] += buckets[s][key];
    }
    const resolved = recent.success + recent.failed;
    frames.push({
      time, ...totals, pending: totals.incoming - totals.success - totals.failed,
      queue: queue.length - head,
      capacity: capacityAt(SCENARIO, time, config),
      recentSuccess: recent.success, recentFailed: recent.failed,
      arrivalRate: time ? recent.incoming / Math.min(5, time) : 0,
      attemptRate: time ? recent.attempts / Math.min(5, time) : 0,
      retryRate: time ? recent.retries / Math.min(5, time) : 0,
      availability: resolved ? recent.success / resolved : null,
      amplification: totals.incoming ? totals.attempts / totals.incoming : 0,
      utilization: time ? Math.min(1, rollingServed / rollingSlots) : 0,
    });
  };

  frame(0);
  for (currentTick = 0; currentTick < ticks; currentTick++) {
    // Apply changes at exact tick boundaries; each scenario defines its incident interval.
    while (actionIndex < run.actions.length && run.actions[actionIndex].at * 10 === currentTick) {
      config = { ...run.actions[actionIndex].policy };
      logs.push({ at: run.actions[actionIndex].at, kind: 'decision', text: `You changed the policy: ${policyDescription(config)}.` });
      actionIndex++;
    }
    if (currentTick === SCENARIO.incidentAt * 10) logs.push({ at: SCENARIO.incidentAt, kind: 'warn', text: SCENARIO.kind === 'surge' ? 'The sale begins. Incoming traffic rises from 48 to 180 customers/s; database capacity is unchanged.' : SCENARIO.kind === 'release' ? 'Version 2 begins serving a more expensive query. Effective database capacity falls from 120 to 24 attempts/s unless rolled back.' : 'Database background maintenance begins. Available service capacity falls from 120 to 12 attempts/s.' });
    if (currentTick === SCENARIO.reliefAt * 10) logs.push({ at: SCENARIO.reliefAt, kind: 'info', text: SCENARIO.kind === 'surge' ? 'The flash sale ends. New traffic returns to 48 customers/s; queued work remains.' : 'Background maintenance ends. Database capacity returns to 120 attempts/s. Queued work is not cancelled.' });

    // Customer arrival randomness is independent of retries and interventions.
    const perTick = arrivalsAt(SCENARIO, currentTick / 10) / 10;
    const arrivals = Math.floor(perTick) + (noise(run.seed, currentTick, 91) < perTick % 1 ? 1 : 0);
    for (let i = 0; i < arrivals; i++) {
      const op = { id: operations.length, created: currentTick, deadline: currentTick + SCENARIO.customerDeadlineMs / STEP_MS, retries: 0, sent: 0, status: 'pending' };
      operations.push(op);
      active.add(op.id);
      totals.incoming++;
      buckets[secondIndex()].incoming++;
      if (noise(run.seed, op.id, 721) * 100 >= config.admission) {
        totals.rejected++;
        finish(op, 'failed');
      } else send(op);
    }

    for (const id of scheduled[currentTick]) {
      const op = operations[id];
      if (op.status === 'pending' && currentTick < op.deadline) send(op);
    }
    scheduled[currentTick] = [];

    const capacity = capacityAt(SCENARIO, currentTick / 10, config);
    credit += capacity / 10;
    const slots = Math.floor(credit + 1e-9);
    credit -= slots;
    slotsThisSecond += slots;
    for (let slot = 0; slot < slots && head < queue.length; slot++) {
      const attempt = queue[head++];
      waiting.delete(attempt.id);
      const op = operations[attempt.operation];
      totals.processed++;
      serviceThisSecond++;
      if (!attempt.timedOut && currentTick <= attempt.expires && op.status === 'pending' && currentTick < op.deadline) finish(op, 'success');
      else totals.wasted++;
    }
    // Unused slots are lost; idle database time cannot be banked for a burst.
    if (head === queue.length) credit = 0;

    for (const [id, attempt] of waiting) {
      if (currentTick >= attempt.expires) {
        waiting.delete(id);
        attempt.timedOut = true;
        totals.timeouts++;
        if (!firstTimeout) {
          firstTimeout = true;
          logs.push({ at: Math.ceil(currentTick / 10), kind: 'warn', text: 'A caller gives up waiting. Its database attempt is still queued; the caller may send another.' });
        }
        failAttempt(attempt);
      }
    }
    // Completed operations leave this set; active work is deadline-bounded.
    for (const id of active) {
      const op = operations[id];
      if (op.status === 'pending' && currentTick >= op.deadline) finish(op, 'failed');
    }
    if (!firstAmplification && totals.attempts > totals.incoming * 1.5) {
      firstAmplification = true;
      logs.push({ at: Math.ceil(currentTick / 10), kind: 'warn', text: 'Cumulative database attempts exceed 1.5 per customer operation. Compare this with incoming traffic.' });
    }
    // Compact the FIFO without changing its order or retaining unbounded data.
    if (head > 1500) { queue.splice(0, head); head = 0; }
    if ((currentTick + 1) % 10 === 0) {
      rollingServed = serviceThisSecond;
      rollingSlots = Math.max(1, slotsThisSecond);
      serviceThisSecond = 0;
      slotsThisSecond = 0;
      frame((currentTick + 1) / 10);
    }
  }
  logs.sort((a, b) => a.at - b.at);
  let recoveredAt = null;
  for (let i = (SCENARIO.kind === 'retries' ? SCENARIO.reliefAt : SCENARIO.incidentAt) + 4; i < frames.length; i++) {
    const stable = frames.slice(i - 4, i + 1).every(f => f.availability !== null && f.availability >= 0.95 && f.queue < SCENARIO.normalCapacity / 2);
    if (stable) { recoveredAt = i; break; }
  }
  const last = frames.at(-1);
  return {
    run, frames, logs,
    summary: {
      scenario: SCENARIO.id, title: SCENARIO.title, duration: SCENARIO.duration, incoming: last.incoming,
      success: last.success, failed: last.failed, pending: last.pending,
      rejected: last.rejected, attempts: last.attempts, retries: last.retries,
      wasted: last.wasted, processed: last.processed, peakQueue: last.maxQueue,
      amplification: last.amplification, successFraction: last.success / last.incoming,
      recoveredAt,
    },
  };
}

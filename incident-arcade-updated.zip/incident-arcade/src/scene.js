const faceHappy = 'M33 63q12 12 24 0';
const faceWorried = 'M33 72q12-12 24 0';

/** Original SVG characters. No external artwork, webfonts, or network requests. */
export function mountScene(container) {
  container.innerHTML = `
  <svg id="system-art" viewBox="0 0 820 300" role="group" aria-label="Interactive checkout system. Select customers, API, or database to inspect evidence.">
    <defs><marker id="arrow" markerWidth="7" markerHeight="7" refX="5" refY="3.5" orient="auto"><path d="m0 0 6 3.5-6 3.5" fill="none" stroke="currentColor" stroke-width="1.3"/></marker></defs>
    <path class="ground-line" d="M35 223q140-3 239 1t235-1 275 1"/>
    <path id="customer-path" class="flow-line customer-flow" d="M173 148C232 147 250 148 307 148" marker-end="url(#arrow)"/>
    <path id="database-path" class="flow-line database-flow" d="M446 148H643" marker-end="url(#arrow)"/>
    <path id="retry-path" class="flow-line retry-flow" d="M600 176C600 250 443 258 423 194" marker-end="url(#arrow)"/>
    <g class="packets" aria-hidden="true"><circle r="4" class="customer-packet"><animateMotion dur="2.4s" repeatCount="indefinite"><mpath href="#customer-path"/></animateMotion></circle><circle r="4" class="customer-packet"><animateMotion dur="2.4s" begin="-1.2s" repeatCount="indefinite"><mpath href="#customer-path"/></animateMotion></circle><circle r="4" class="database-packet"><animateMotion dur="1.8s" repeatCount="indefinite"><mpath href="#database-path"/></animateMotion></circle><circle r="4" class="database-packet"><animateMotion dur="1.8s" begin="-.6s" repeatCount="indefinite"><mpath href="#database-path"/></animateMotion></circle><circle r="4" class="database-packet"><animateMotion dur="1.8s" begin="-1.2s" repeatCount="indefinite"><mpath href="#database-path"/></animateMotion></circle><circle r="4" class="retry-packet"><animateMotion dur="2s" repeatCount="indefinite"><mpath href="#retry-path"/></animateMotion></circle></g>
    <text x="238" y="128" text-anchor="middle" class="diagram-rate" id="art-customer-rate">48 / sec</text>
    <text x="544" y="128" text-anchor="middle" class="diagram-rate" id="art-attempt-rate">-- / sec</text>
    <text id="retry-caption" x="522" y="269" text-anchor="middle" class="diagram-small">again? ...again.</text>
    <g role="button" tabindex="0" class="scene-character" data-evidence="traffic" aria-label="Inspect incoming customer traffic">
      <ellipse class="character-shadow" cx="112" cy="214" rx="57" ry="7"/>
      <path d="M82 176v29l-16 7m72-36v29l16 7" class="ink-line"/>
      <path d="M68 139q-18 3-24 24m109-22q19 1 22 20" class="ink-line"/>
      <path d="m64 105 94-2 5 80-99 4z" fill="#e7cf9c" class="art-outline"/>
      <path d="M89 112V95q0-26 24-26t24 27v16" class="ink-line"/>
      <path d="M89 110v-9m47 9v-9" class="ink-line"/>
      <g class="character-eyes"><circle cx="96" cy="143" r="3"/><circle cx="129" cy="143" r="3"/></g>
      <path d="M105 156q8 8 16-1" class="ink-line"/>
      <path d="m77 121 10-1" stroke="#fdfbf6" stroke-width="4" stroke-linecap="round"/>
      <rect x="61" y="236" width="104" height="27" rx="13.5" class="node-tag"/><text x="113" y="254" text-anchor="middle" class="diagram-label">Customers</text>
    </g>
    <g role="button" tabindex="0" class="scene-character" data-evidence="changes" aria-label="Inspect the shop server and recent changes">
      <ellipse class="character-shadow" cx="378" cy="214" rx="66" ry="8"/>
      <path d="M350 185v22l-12 5m71-26v21l14 5" class="ink-line"/>
      <path d="M319 147q-15 6-19 24m136-24q15 2 19 15" class="ink-line"/>
      <path d="m325 86 98-2 14 15-2 90-109 2z" fill="#8bbbac" class="art-outline"/>
      <path d="m326 86 14 14 96-1m-96 1-1 90" class="ink-line thin"/>
      <rect x="351" y="116" width="68" height="48" rx="5" fill="#eaf0dc" class="art-outline thin"/>
      <g class="character-eyes"><circle cx="371" cy="136" r="3"/><circle cx="397" cy="136" r="3"/></g>
      <path id="api-mouth" d="M377 148q8 7 16 0" class="ink-line thin"/>
      <circle cx="355" cy="177" r="3" fill="#282e2a"/><path d="M368 177h41" class="ink-line thin"/>
      <rect x="339" y="236" width="79" height="27" rx="13.5" class="node-tag"/><text x="379" y="254" text-anchor="middle" class="diagram-label">Shop server</text>
    </g>
    <g aria-hidden="true"><path d="M625 27q66-6 152 0l-1 35-51 1-14 16-2-16-84-2z" fill="#fffdf8" class="bubble-outline"/><text id="db-speech" x="701" y="49" text-anchor="middle" class="diagram-small">a little backed up.</text></g>
    <g role="button" tabindex="0" class="scene-character" data-evidence="database" aria-label="Inspect database capacity and queue">
      <ellipse class="character-shadow" cx="708" cy="214" rx="64" ry="8"/>
      <g transform="translate(661 93)"><path d="M24 97v17l-12 5m57-23v18l14 5" class="ink-line"/>
      <path d="M1 30v55c0 23 93 23 93 0V30" fill="#e8a080" class="art-outline"/>
      <path d="M1 54c0 23 93 23 93 0m-93 24c0 23 93 23 93 0" class="ink-line thin"/>
      <ellipse cx="47.5" cy="30" rx="46.5" ry="17" fill="#f0c3a6" class="art-outline"/>
      <g class="character-eyes"><circle cx="31" cy="61" r="3"/><circle cx="60" cy="61" r="3"/></g><path id="db-mouth" d="${faceWorried}" class="ink-line thin"/>
      <path id="db-sweat" d="M99 36q12 15 1 16t-1-16" fill="#88b8b1" stroke="#282e2a" stroke-width="1.5"/>
      </g><rect x="659" y="236" width="100" height="27" rx="13.5" class="node-tag"/><text x="709" y="254" text-anchor="middle" class="diagram-label">Database</text>
    </g>
    <g id="queue-pile" aria-hidden="true">${Array.from({length: 12}, (_, i) => `<rect class="queue-ticket" x="${542 + (i % 3) * 15}" y="${113 - Math.floor(i / 3) * 10}" width="12" height="7" rx="2"/>`).join('')}</g>
    <text id="queue-label" x="562" y="61" text-anchor="middle" class="diagram-small">a queue is forming</text>
  </svg>`;
}

export function updateScene(frame, playing, reduced, selected) {
  const svg = document.getElementById('system-art');
  if (!svg) return;
  document.getElementById('art-customer-rate').textContent = `${Math.round(frame.arrivalRate)} / sec`;
  document.getElementById('art-attempt-rate').textContent = `${Math.round(frame.attemptRate)} / sec`;
  const retrying = frame.retryRate > 0;
  document.getElementById('retry-path').style.opacity = retrying ? '1' : '0';
  document.getElementById('retry-caption').style.opacity = retrying ? '1' : '0';
  document.querySelectorAll('.retry-packet').forEach(node => { node.style.opacity = retrying ? '1' : '0'; });
  const stressed = frame.queue > 120;
  document.getElementById('db-mouth').setAttribute('d', stressed ? faceWorried : faceHappy);
  document.getElementById('api-mouth').setAttribute('d', stressed ? 'M377 153q8-7 16 0' : 'M377 148q8 7 16 0');
  document.getElementById('db-sweat').style.opacity = stressed ? '1' : '0';
  document.getElementById('db-speech').textContent = frame.queue > 600 ? (frame.retryRate > 1 ? 'I have this one already.' : 'too many at once.') : stressed ? 'a little backed up.' : 'one at a time. nice.';
  document.getElementById('queue-label').textContent = frame.queue ? `${frame.queue.toLocaleString()} waiting` : 'room to breathe';
  document.querySelectorAll('.queue-ticket').forEach((node, index) => { node.style.opacity = index < Math.ceil(frame.queue / 100) ? '1' : '.08'; });
  document.querySelectorAll('.scene-character').forEach(node => node.classList.toggle('selected', node.dataset.evidence === selected));
  svg.classList.toggle('stressed', stressed);
  svg.classList.toggle('still', reduced || !playing);
  try { if (reduced || !playing) svg.pauseAnimations(); else svg.unpauseAnimations(); } catch { /* Some SVG implementations do not expose animation controls. */ }
}

/** Small, fictional workloads. Rates are assumptions, never production estimates. */
export const ENGINE_VERSION = '2.0.0';
const base = {version:1,duration:90,startAt:18,incidentAt:10,normalCapacity:120,maxQueue:1200,customerDeadlineMs:8000};
export const SCENARIOS = Object.freeze([
  Object.freeze({...base,id:'retry-storm',title:'The midnight checkout',kind:'retries',reliefAt:24,arrivalsPerSecond:48,impairedCapacity:12,initial:Object.freeze({retries:3,backoff:'immediate',timeoutMs:1200,admission:100})}),
  Object.freeze({...base,id:'flash-sale',title:'Everybody wants a tote',kind:'surge',reliefAt:70,arrivalsPerSecond:48,surgeArrivals:180,impairedCapacity:120,initial:Object.freeze({retries:0,backoff:'immediate',timeoutMs:1200,admission:100,replicas:1})}),
  Object.freeze({...base,id:'bad-rollout',title:'It worked on my laptop',kind:'release',reliefAt:90,arrivalsPerSecond:48,impairedCapacity:24,initial:Object.freeze({retries:1,backoff:'jitter',timeoutMs:3000,admission:100,rollback:false})}),
]);
export const SCENARIO = SCENARIOS[0];
export const LIMITS = Object.freeze({maxActions:64,maxRunBytes:24000,maxLinkLength:34000});
export const OPTIONS = Object.freeze({retries:[0,1,3,6],backoff:['immediate','jitter'],timeoutMs:[600,1200,3000,5000],admission:[50,75,100]});
export function getScenario(id='retry-storm') {
  const found = SCENARIOS.find(s=>s.id===id);
  if (!found) throw new Error('Unknown incident. Choose one of the three included cases.');
  return found;
}
export function optionsFor(scenario) {
  return {...OPTIONS,...(scenario.kind==='surge'?{replicas:[1,2]}:{}),...(scenario.kind==='release'?{rollback:[false,true]}:{})};
}
export function capacityAt(scenario, second, policy) {
  const impaired=second>=scenario.incidentAt && second<scenario.reliefAt;
  const baseCapacity=impaired && !(scenario.kind==='release' && policy.rollback) ? scenario.impairedCapacity : scenario.normalCapacity;
  return baseCapacity*(policy.replicas??1);
}
export function arrivalsAt(scenario,second) {
  return scenario.kind==='surge' && second>=scenario.incidentAt && second<scenario.reliefAt ? scenario.surgeArrivals : scenario.arrivalsPerSecond;
}
export function newRun(seed=42,scenarioId='retry-storm') {
  const scenario=getScenario(scenarioId);
  return {format:1,engine:ENGINE_VERSION,scenario:scenario.id,scenarioVersion:scenario.version,seed,actions:[]};
}

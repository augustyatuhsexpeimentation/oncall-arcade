/** Canvas drawing shared by the browser export and optional maintainer tooling. */
export function drawShareCard(ctx, reference, current, label = 'A free, open-source experiment. No real servers harmed.') {
  const W = 1200, H = 630;
  ctx.fillStyle = '#f5f1e8'; ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = '#282e2a';
  ctx.font = 'bold 23px sans-serif'; ctx.fillText('incident arcade', 65, 64);
  ctx.font = '13px monospace'; ctx.fillText(`${(current.title || 'A small incident').toUpperCase()} / A REPLAYABLE INCIDENT`, 65, 101);
  ctx.font = '62px Georgia, serif'; ctx.fillText('Same outage.', 62, 193);
  ctx.font = 'italic 62px Georgia, serif'; ctx.fillText('Different decisions.', 62, 264);
  ctx.strokeStyle = '#c86e48'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(63, 279); ctx.quadraticCurveTo(285, 267, 584, 280); ctx.stroke();
  const rect = (x, y, w, h, color) => { ctx.fillStyle = color; ctx.beginPath(); ctx.roundRect(x,y,w,h,14); ctx.fill(); ctx.strokeStyle = '#c0c7b8'; ctx.lineWidth = 1; ctx.stroke(); };
  rect(65, 326, 330, 185, '#eeeadd'); rect(415, 326, 330, 185, '#dfeadd');
  const card = (x, summary, name) => {
    ctx.fillStyle = '#565f50'; ctx.font = '13px monospace'; ctx.fillText(name, x + 23, 359);
    ctx.fillStyle = '#282e2a'; ctx.font = '53px monospace'; ctx.fillText(summary.success.toLocaleString('en-US'), x + 23, 420);
    ctx.font = '15px sans-serif'; ctx.fillText('successful customer checkouts', x + 23, 451);
    ctx.fillStyle = '#626b5d'; ctx.font = '11px monospace'; ctx.fillText(`${summary.failed} failed / ${summary.pending} pending at 90s`, x + 23, 482);
  };
  card(65, reference, 'REFERENCE TIMELINE'); card(415, current, 'MY TIMELINE');
  ctx.save(); ctx.translate(890, 270); ctx.rotate(-.08);
  ctx.fillStyle = '#282e2a'; ctx.fillRect(10, -38, 165, 190);
  rect(0, -50, 165, 190, '#8bbbac'); rect(24, -20, 118, 96, '#eaf0dc');
  ctx.fillStyle = '#282e2a'; ctx.beginPath(); ctx.arc(60, 21, 5, 0, Math.PI*2);ctx.arc(110,21,5,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle = '#282e2a'; ctx.lineWidth = 4;ctx.beginPath();ctx.moveTo(66,46);ctx.quadraticCurveTo(84,64,104,46);ctx.stroke();
  ctx.fillRect(27, 99, 10, 10);ctx.fillRect(49, 102, 88, 4);
  ctx.beginPath(); ctx.moveTo(39,145);ctx.lineTo(39,174);ctx.lineTo(22,180);ctx.moveTo(127,145);ctx.lineTo(127,174);ctx.lineTo(145,180);ctx.stroke();
  ctx.restore();
  ctx.fillStyle = '#34786b';ctx.font = 'italic 24px Georgia, serif';ctx.fillText('Experiment. Rewind.', 842, 477);ctx.fillText('Understand.', 875, 509);
  ctx.strokeStyle = '#d3d6c8';ctx.lineWidth = 1;ctx.beginPath();ctx.moveTo(65,550);ctx.lineTo(1135,550);ctx.stroke();
  ctx.fillStyle = '#626b5d';ctx.font = '12px monospace';ctx.fillText(label.slice(0, 100), 65, 582);
  ctx.font = '10px monospace';ctx.fillText('ILLUSTRATIVE MODEL / EQUAL 90-SECOND HORIZONS', 65, 606);
}

export function downloadBlob(blob, name) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a'); link.href = url; link.download = name;
  document.body.append(link); link.click(); link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export async function downloadShareCard(reference, current) {
  const canvas = document.createElement('canvas'); canvas.width = 1200; canvas.height = 630;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Your browser cannot create a share image. Export the JSON run instead.');
  drawShareCard(ctx, reference, current);
  const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
  if (!blob) throw new Error('Image export failed. Try a different browser.');
  downloadBlob(blob, 'incident-arcade-my-timelines.png');
}

/** Original miniature score + sound effects. MIT licensed; no samples or requests. */
export const MUSIC_BPM = 84;
export const MUSIC_NOTES = Object.freeze([
  [60,64,67,71], [57,60,64,67], [53,57,60,64], [55,60,62,67],
]);
export const FX = Object.freeze({
  clue:[[76,0,.10],[83,.09,.16]],
  choose:[[60,0,.08],[67,.065,.12]],
  rewind:[[81,0,.12],[76,.07,.12],[69,.14,.18],[60,.21,.2]],
  result:[[60,0,.19],[64,.12,.19],[67,.24,.32]],
  pager:[[72,0,.09],[72,.15,.09]],
  answer:[[67,0,.12],[72,.10,.22]],
});
export function noteHz(midi) { return 440 * 2 ** ((midi - 69) / 12); }
export class ArcadeAudio {
  constructor(onChange=()=>{}) {
    this.context=null;this.effects=false;this.music=false;this.volume=.35;this.hidden=false;
    this.timer=null;this.voices=new Set();this.onChange=onChange;this.lastEffect=-Infinity;this.unavailable=false;this.requests={effects:0,music:0};
  }
  async unlock() {
    try {
      const Context=globalThis.AudioContext||globalThis.webkitAudioContext;
      if(!Context) throw new Error('Web Audio is not supported');
      if(!this.context) {
        this.context=new Context();this.master=this.context.createGain();
        this.master.gain.value=this.volume*.28;this.master.connect(this.context.destination);
      }
      if(this.context.state==='suspended'&&!this.hidden) await this.context.resume();
      return true;
    } catch {this.unavailable=true;this.effects=false;this.music=false;this.onChange();return false;}
  }
  async setEnabled(kind,enabled) {
    if(!['effects','music'].includes(kind)) return false;
    const request=++this.requests[kind];
    if(enabled && !(await this.unlock())) return false;
    if(request!==this.requests[kind]) return false;
    this[kind]=!!enabled;
    if(kind==='music') enabled?this.startMusic():this.stopMusic();
    if(kind==='effects'&&!enabled) this.stopVoices('effects');
    this.onChange();return true;
  }
  setVolume(value) {
    this.volume=Math.max(0,Math.min(1,Number(value)||0));
    if(this.master) this.master.gain.setTargetAtTime(this.volume*.28,this.context.currentTime,.04);
  }
  tone(note,at,duration,gain=.15,group='effects',type='sine') {
    const ctx=this.context;if(!ctx||ctx.state!=='running'||this.hidden||this.voices.size>=48) return;
    const osc=ctx.createOscillator(),amp=ctx.createGain();
    osc.type=type;osc.frequency.value=noteHz(note);
    amp.gain.setValueAtTime(0,at);amp.gain.linearRampToValueAtTime(gain,at+.012);
    amp.gain.exponentialRampToValueAtTime(.0001,at+duration);
    osc.connect(amp);amp.connect(this.master);
    const voice={osc,amp,group};this.voices.add(voice);
    osc.onended=()=>{osc.disconnect();amp.disconnect();this.voices.delete(voice);};
    osc.start(at);osc.stop(at+duration+.025);
  }
  play(name) {
    if(!this.effects||this.hidden||!this.context||this.context.state!=='running') return;
    const now=this.context.currentTime;
    if(now-this.lastEffect<.06) return;
    this.lastEffect=now;
    for(const [note,offset,length] of FX[name]||FX.choose) this.tone(note,now+.01+offset,length,.22);
  }
  startMusic() {
    if(this.timer||!this.music||!this.context||this.hidden||this.context.state!=='running') return;
    const beat=60/MUSIC_BPM;let step=0,next=this.context.currentTime+.08;
    const schedule=()=>{
      if(this.hidden||!this.music||this.context.state!=='running') return;
      // Bound catch-up after a stalled event loop rather than scheduling a burst.
      if(next<this.context.currentTime) next=this.context.currentTime+.06;
      while(next<this.context.currentTime+.22) {
        const chord=MUSIC_NOTES[Math.floor(step/16)%4];
        const motif=[0,2,1,3,2,1,3,2];
        this.tone(chord[motif[step%8]]+12,next,.7,.10,'music');
        if(step%4===0) this.tone(chord[0]-12,next,1.25,.17,'music','sine');
        next+=beat/2;step=(step+1)%64;
      }
    };
    schedule();this.timer=setInterval(schedule,100);
  }
  stopVoices(group) {
    for(const v of this.voices) if(!group||v.group===group) {
      try {v.amp.gain.cancelScheduledValues(this.context.currentTime);v.amp.gain.setTargetAtTime(.0001,this.context.currentTime,.025);v.osc.stop(this.context.currentTime+.1);} catch {}
    }
  }
  stopMusic() {if(this.timer) clearInterval(this.timer);this.timer=null;this.stopVoices('music');}
  async setHidden(hidden) {
    this.hidden=!!hidden;
    if(hidden) {
      this.stopMusic();this.stopVoices();
      if(this.context?.state==='running') {try {await this.context.suspend();} catch {}}
    } else if(this.context&&(this.effects||this.music)) {
      if(await this.unlock()) this.startMusic();
    }
  }
  async dispose() {this.stopMusic();this.stopVoices();if(this.context){try{await this.context.close();}catch{}}}
}

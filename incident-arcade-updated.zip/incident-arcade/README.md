# Incident Arcade

### Oops. You're on call.

**An illustrated, rewindable game about fixing a broken online shop.**
Find a clue. Try a fix. See the consequences. Rewind and compare.

No signup. No paid API. No backend. No packages to install.

<!-- LIVE_LINK_START -->
**Try it:** extract the ZIP and open `preview.html`. For development, run `node scripts/serve.mjs` and open `http://localhost:5173`.
<!-- LIVE_LINK_END -->

![An exported comparison card from the teaching simulation](assets/social-card.png)

*This is a result-card illustration, not a screenshot of the updated interface. Its retry-storm numbers come from the shipped model.*

## Three small incidents

| Case | The puzzle | What it teaches |
| --- | --- | --- |
| The retry storm | The shop is quiet, but the database is overloaded. | Repeated attempts can amplify a slowdown. |
| The flash crowd | More shoppers arrive than one worker can serve. | Capacity, queues, and the cost of rejecting customers. |
| The bad release | A new version makes each checkout more expensive. | Follow the change history; distinguish a cause from a symptom. |

Each case models 90 seconds of a fictional incident. These are accessible teaching puzzles, not replicas of production infrastructure. The first-session design target is roughly 10-20 minutes including reading and experimentation; this has not been established through user testing.

## Play first, learn the controls later

Start with one clear goal and a short explanation. Click the illustrated customers, shop server, or database to reveal clues. Pick one of three plain-language fixes. Watch the results, then use **Rewind & try another** to compare the same incident under a different decision.

Advanced sliders, the timeline, and export tools live in optional free play. Hints, explanations, and a short reflection are available without locking later cases. All three cases are accessible from the start. Progress stays in your browser, when local storage is available.

The original paper-and-ink scene, expressive SVG characters, moving requests, and notebook remain. Broad interaction inspiration: [Nicky Case](https://ncase.me/) and [Neal.fun](https://neal.fun/). No artwork or code from either site is included; this project is not affiliated with them.

## Optional audio

Open **Audio off** to enable effects or the background tune independently. Both start disabled on every page load. The original procedural score and effects are generated locally by `src/audio.js` and released under the project's MIT license. There are no downloaded recordings or external audio requests. Volume is adjustable; audio stops when the page is hidden. See [docs/AUDIO.md](docs/AUDIO.md).

## Run or edit

To play locally, open the included **`preview.html`**. Nothing needs installing.

For editing, install Node.js 22 or newer and run:

```sh
node scripts/serve.mjs
```

Open `http://localhost:5173`. Do not double-click normal `index.html`, which imports the separate source modules. No `npm install` is needed.

| Task | Command |
| --- | --- |
| Automated tests | `node --test tests/*.test.mjs` |
| JavaScript syntax checks | `node scripts/check.mjs` |
| Browser checks, with Chrome installed | `node scripts/browser-smoke.mjs` |
| Rebuild the offline preview after edits | `node scripts/standalone.mjs` |
| Optional clean deployment folder | `node scripts/build.mjs` |

The source folder itself is already a static website. Building `dist/` is optional, not a prerequisite for GitHub Pages.

## Publish

Use [docs/PUBLISH.md](docs/PUBLISH.md): create a public GitHub repository, push this folder's contents, and publish `main` / `/(root)` with GitHub Pages. No coding-agent prompt is necessary.

## What makes comparisons fair?

`same version + same scenario + same seed + same decisions = same outcome`

The arrival stream does not change when you choose a different fix. Each customer can succeed once, even when they send repeated attempts. Rejected customers remain failures. Results compare the same 90-second period, not unequal snapshots.

This is a bounded queue model with timeouts, retries, admission, and scenario-specific capacity changes. It is not a cloud emulator, hiring test, or operational runbook. Instant scaling and safe rollback are explicit fictional assumptions. See [docs/MODEL.md](docs/MODEL.md).

## Repository map

```text
src/engine.js       Deterministic model, validation, branching
src/scenario.js     Three versioned workloads and available policies
src/episodes.js     Clues, choices, explanations, and source reading
src/app.js          Guided journey, free play, sharing, persistence
src/scene.js        Original illustrated scene and measured animation
src/audio.js        Original opt-in score and sound effects
src/progress.js     Local progress and result summaries
src/replay.js       Bounded replay links and file validation
src/share-card.js   Locally generated PNG comparison cards
src/worker.js       Background simulation, with main-thread fallback
scripts/           Local server, packaging, configuration, QA
```

## Verification and limits

**110 automated tests passed.** This includes deterministic-engine tests, replay validation, packaging/server tests, audio-controller mocks, and a nonvisual interaction harness for the three guided cases.

**Real-browser visual review and listening checks were not completed in the build environment.** Mock audio and DOM checks are not substitutes for these. The included browser script and GitHub Actions workflow are set up to perform real-browser checks and capture screenshots, but their successful execution is not claimed. See [docs/VERIFICATION.md](docs/VERIFICATION.md).

There is no evidence yet for retention, improved learning outcomes, or likely GitHub stars. Design research and the decisions it informed are documented in [docs/RESEARCH.md](docs/RESEARCH.md).

## Privacy and license

No analytics, tracking scripts, external fonts, accounts, or AI calls. The static hosting provider may log ordinary web requests. Local progress can be cleared. Replay links contain the scenario, seed, and choices, not personal information, notebook progress, or the reference timeline.

Original code, SVG artwork, audio composition, and generated assets: [MIT](LICENSE). Source articles remain their authors' work; only links and original explanations are included. Contributions: [CONTRIBUTING.md](CONTRIBUTING.md).

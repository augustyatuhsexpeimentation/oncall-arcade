# Changes

## 2.0.0 - October 29, 2026

- Retain the original illustrated scene; add a goal-first guided flow and defer advanced controls.
- Add flash-crowd and reversible-bad-release incidents with distinct modeled causes.
- Add automatic rewind/compare, explanations, optional reflection, local case progress, and a case picker.
- Add original opt-in Web Audio music and effects, separate controls, volume, and tab-hidden suspension.
- Keep deterministic comparisons, JSON/replay links, PNG cards, and free-play tools.
- Add scenario, audio-mock, and nonvisual guided-interaction tests; 110 automated tests pass.
- Include a regenerated offline preview in the same source package and remove the redundant coding-agent prompt.
- Preserve v1 retry-storm replay compatibility; do not migrate v1 local UI saves.

Real-browser visual review and audio listening remain outstanding; see docs/VERIFICATION.md.
